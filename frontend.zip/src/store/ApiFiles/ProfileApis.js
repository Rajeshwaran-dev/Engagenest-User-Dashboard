import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const ProfileApis = createApi({
  reducerPath: "ProfileApis",
  tagTypes: ["Campaigns", "Role"],
  baseQuery: fetchBaseQuery({
    baseUrl: `${process.env.REACT_APP_API_URL}users`,
    prepareHeaders: headers => {
      const loginDetails = JSON.parse(localStorage.getItem("loginData"));

      if (loginDetails?.token) {
        headers.set("Authorization", `Bearer ${loginDetails?.token}`);
      }

      return headers;
    },
  }),
  keepUnusedDataFor: 0,
  endpoints: builder => ({
    getProfile: builder.query({
      query: () => `/profile`,
    }),
    updateProfile: builder.mutation({
      query: profileData => ({
        url: `/profile`,
        method: "PATCH",
        body: profileData,
      }),
    }),
    removeProfilePicture: builder.mutation({
      query: () => ({
        url: `/profile`,
        method: "PATCH",
        body: { profile_picture_url: "" },
      }),
    }),
  }),
});

export const {
  useGetProfileQuery,
  useUpdateProfileMutation,
  useRemoveProfilePictureMutation,
} = ProfileApis;
