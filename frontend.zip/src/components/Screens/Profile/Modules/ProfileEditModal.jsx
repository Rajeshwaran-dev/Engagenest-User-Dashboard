import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useState } from "react";

const ProfileEditModal = ({ showModal, setShowModal }) => {
  const [imagePreview, setImagePreview] = useState("");

  // Function to close modal
  const handleCloseModal = () => {
    setShowModal(false);
  };

  // Function to handle image upload preview
  const readURL = (event) => {
    const input = event.target;
    if (input.files && input.files[0]) {
      const reader = new FileReader();
      reader.onload = function (e) {
        setImagePreview(e.target.result);
      };
      reader.readAsDataURL(input.files[0]);
    }
  };

  // Function to handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted");
    setShowModal(false);
  };

  // Don't render if showModal is false
  if (!showModal) return null;

  return (
    <div
      className="modal fade show d-block"
      style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
    >
      <div className="modal-dialog modal-lg modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <div className="d-flex align-items-center">
              <div>
                <Icon className="modal-icon-adjustments" icon="gg:profile" />
              </div>
              <h3 style={{ marginTop: "2px", marginLeft: "10px" }}>
                Edit Profile
              </h3>
            </div>
            <button
              type="button"
              className="btn-close"
              onClick={handleCloseModal}
            >
              <Icon icon="mingcute:close-line" />
            </button>
          </div>

          <div className="modal-body">
            <div className="tab-pane fade show active">
              <h6 className="text-md text-primary-light mb-16">
                Profile Image
              </h6>
              <div className="mb-24 mt-16">
                <div className="avatar-upload">
                  <div className="avatar-edit position-absolute bottom-0 end-0 me-24 mt-16 z-1 cursor-pointer">
                    <input
                      type="file"
                      id="imageUpload"
                      accept=".png, .jpg, .jpeg"
                      hidden
                      onChange={readURL}
                    />
                    <label
                      htmlFor="imageUpload"
                      className="w-32-px h-32-px d-flex justify-content-center align-items-center bg-primary-50 text-primary-600 border border-primary-600 bg-hover-primary-100 text-lg rounded-circle"
                    >
                      <Icon icon="solar:camera-outline" className="icon"></Icon>
                    </label>
                  </div>
                  <div className="avatar-preview">
                    <div id="imagePreview" />
                  </div>
                </div>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="row">
                  <div className="col-sm-6">
                    <div className="mb-20">
                      <label
                        htmlFor="name"
                        className="form-label fw-semibold text-primary-light text-sm mb-8"
                      >
                        WhatsApp About
                        <span className="text-danger-600">*</span>
                      </label>
                      <input
                        type="text"
                        className="form-control radius-8"
                        id="name"
                        placeholder="WhatsApp About"
                        required
                      />
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="mb-20">
                      <label
                        htmlFor="email"
                        className="form-label fw-semibold text-primary-light text-sm mb-8"
                      >
                        Email <span className="text-danger-600">*</span>
                      </label>
                      <input
                        type="email"
                        className="form-control radius-8"
                        id="email"
                        placeholder="Enter email address"
                        required
                      />
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="mb-20">
                      <label
                        htmlFor="address"
                        className="form-label fw-semibold text-primary-light text-sm mb-8"
                      >
                        Address
                      </label>
                      <input
                        type="text"
                        className="form-control radius-8"
                        id="address"
                        placeholder="Enter full Address"
                      />
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="mb-20">
                      <label
                        htmlFor="businessVertical"
                        className="form-label fw-semibold text-primary-light text-sm mb-8"
                      >
                        Business Vertical
                        <span className="text-danger-600">*</span>{" "}
                      </label>
                      <select
                        className="form-control radius-8 form-select"
                        id="businessVertical"
                        defaultValue=""
                        required
                      >
                        <option value="" disabled>
                          Select Business Vertical
                        </option>
                        <option value="Event Planning and Services">
                          Event Planning and Services
                        </option>
                        <option value="Finance and Banking">
                          Finance and Banking
                        </option>
                        <option value="Food and Groceries">
                          Food and Groceries
                        </option>
                        <option value="Public Service">Public Service</option>
                        <option value="Hotel and Lodging">
                          Hotel and Lodging
                        </option>
                        <option value="Medical and Health">
                          Medical and Health
                        </option>
                        <option value="Charity">Charity</option>
                        <option value="Professional Service">
                          Professional Service
                        </option>
                      </select>
                    </div>
                  </div>
                  <div className="col-sm-6">
                    <div className="mb-20">
                      <label
                        htmlFor="website"
                        className="form-label fw-semibold text-primary-light text-sm mb-8"
                      >
                        Website
                      </label>
                      <input
                        type="url"
                        className="form-control radius-8"
                        id="website"
                        placeholder="Enter website URL"
                      />
                    </div>
                  </div>
                  <div className="col-sm-12">
                    <div className="mb-20">
                      <label
                        htmlFor="desc"
                        className="form-label fw-semibold text-primary-light text-sm mb-8"
                      >
                        Description
                      </label>
                      <textarea
                        className="form-control radius-8"
                        id="desc"
                        placeholder="Write description..."
                        rows="4"
                      />
                    </div>
                  </div>
                </div>

                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn-secondary"
                    onClick={handleCloseModal}
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="btn-primary"
                  >
                    Save
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileEditModal;
