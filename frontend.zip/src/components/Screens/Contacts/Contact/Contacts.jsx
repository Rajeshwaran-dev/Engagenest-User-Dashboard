import React, { useState, useEffect, useRef } from "react";
import MasterLayout from "../../../../masterLayout/MasterLayout";
import Breadcrumb from "../../../Breadcrumb";
import { Icon } from "@iconify/react/dist/iconify.js";
import { Link, useNavigate } from "react-router-dom";
import ContactActionModal from "../Modules/ContactActionModal";
import ImportContactsModal from "../Modules/ImportModal";
import { useSnackbar } from "notistack";
import {
  useGetAllContactsQuery,
  useCreateContactMutation,
  useDeleteContactsMutation,
  useEditContactMutation,
  useMoveContactToGroupMutation,
  useCopyContactMutation,
  useExportOneContactMutation,
  useGetAllContactGroupsQuery
} from "../../../../store/ApiFilesV2/ContactApis";
import { useGetUserAttrQuery } from "../../../../store/ApiFilesV2/UserApis";

const Contacts = () => {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();
  const isMounted = useRef(true);

  const [modalType, setModalType] = useState(null);
  const [showImportModal, setShowImportModal] = useState(false);
  const [contacts, setContacts] = useState([]);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [isBulkDeleteModalOpen, setIsBulkDeleteModalOpen] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  // console.log(contacts, 'contect')
  // console.log(editingContact, "editcontact")

  const [formData, setFormData] = useState({
    group: "",
    countryCode: "+91",
    mobileNumber: "",
    contactName: "",
    tags: "",
  });

  const [moveData, setMoveData] = useState({
    currentGroup: "",
    availableGroups: "",
    contactId: null
  });

  const [copyData, setCopyData] = useState({
    availableGroups: "",
    contactId: null,
    currentGroups: ""
  });

  // Fetch user attributes
  const { data: userAttributesData } = useGetUserAttrQuery(undefined, {
    skip: !isAuthenticated,
  });

  // Check authentication status
  useEffect(() => {
    const checkAuth = () => {
      try {
        const loginDetails = JSON.parse(localStorage.getItem("loginData"));
        const authenticated = !!loginDetails?.token;
        if (isMounted.current) {
          setIsAuthenticated(authenticated);
        }
        return authenticated;
      } catch (error) {
        if (isMounted.current) {
          setIsAuthenticated(false);
        }
        return false;
      }
    };

    checkAuth();

    // Listen for storage changes (login/logout)
    const handleStorageChange = () => {
      if (isMounted.current) {
        checkAuth();
      }
    };

    window.addEventListener('storage', handleStorageChange);

    return () => {
      isMounted.current = false;
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const {
    data: contactsData,
    isLoading: contactsLoading,
    error: contactsError,
    refetch: refetchContacts
  } = useGetAllContactsQuery({
    offset: 0,
    limit: 100,
    groups: "null"
  }, {
    skip: !isAuthenticated,
    // Add refetchOnMountOrArgChange to ensure fresh data
    refetchOnMountOrArgChange: true,
  });

  // console.log(contactsData, 'fdgdfgfdg')

  useEffect(() => {
    if (contactsData) {
      // console.log("Raw contactsData from API:", contactsData);

      // Check the structure
      if (contactsData.data && Array.isArray(contactsData.data)) {
        // console.log("First contact in API response:", contactsData.data[0]);
        console.log("ID fields in first contact:", {
          _id: contactsData.data[0]?._id,
          id: contactsData.data[0]?.id,
          contactId: contactsData.data[0]?.contactId,
          uuid: contactsData.data[0]?.uuid
        });
      }
    }
  }, [contactsData])

  const {
    data: groupsData,
    isLoading: groupsLoading,
    error: groupsError,
    refetch: refetchGroups
  } = useGetAllContactGroupsQuery(undefined, {
    skip: !isAuthenticated,
  });

  const [createContact] = useCreateContactMutation();
  const [deleteContacts] = useDeleteContactsMutation();
  const [editContact] = useEditContactMutation();
  const [moveContactToGroup] = useMoveContactToGroupMutation();
  const [copyContact] = useCopyContactMutation();
  const [exportOneContact] = useExportOneContactMutation();

  // Get available groups from API
  const availableGroups = React.useMemo(() => {
    if (groupsData?.data) {
      return groupsData.data.map(group => group.name);
    }
    return [];
  }, [groupsData]);

  useEffect(() => {
    if (!isAuthenticated) {
      setContacts([]);
      return;
    }

    // Only process if we have data and not loading
    if (contactsData && !contactsLoading && groupsData) {
      let dataArray = [];

      // Handle different response structures - same as before
      if (Array.isArray(contactsData)) {
        dataArray = contactsData;
      } else if (contactsData.data && Array.isArray(contactsData.data)) {
        dataArray = contactsData.data;
      } else if (contactsData.contacts && Array.isArray(contactsData.contacts)) {
        dataArray = contactsData.contacts;
      } else if (contactsData.result && Array.isArray(contactsData.result)) {
        dataArray = contactsData.result;
      } else if (contactsData.results && Array.isArray(contactsData.results)) {
        dataArray = contactsData.results;
      } else if (contactsData.body && Array.isArray(contactsData.body)) {
        dataArray = contactsData.body;
      } else if (contactsData.response && Array.isArray(contactsData.response)) {
        dataArray = contactsData.response;
      }

      if (dataArray && Array.isArray(dataArray)) {
        // Create a Set to track unique contact IDs to prevent duplicates
        const uniqueContactIds = new Set();
        const transformedContacts = [];

        dataArray.forEach((contact, index) => {
          // FIX: Better ID extraction with validation
          const apiId = contact._id || contact.id || contact.contactId || contact.uuid;

          // Debug: Log what we're getting
          console.log(`Contact ${index} - Raw ID fields:`, {
            _id: contact._id,
            id: contact.id,
            contactId: contact.contactId,
            uuid: contact.uuid,
            rawContact: contact
          });

          // Validate the ID - it should be a valid MongoDB ID or meaningful string
          let contactId;
          if (apiId && apiId !== "." && apiId.trim() !== "" && apiId.length > 5) {
            // Use the API ID if it's valid
            contactId = apiId;
            // console.log(`Using valid API ID: ${contactId}`);
          } else {
            // Create a stable fallback ID based on phone number + name
            const phone = contact.contactNumber || contact.phoneNumber || contact.mobileNumber || contact.number || "";
            const name = contact.contactName || contact.name || "unknown";
            contactId = `temp-${name.replace(/\s+/g, '-')}-${phone}-${index}`;
            // console.log(`Using fallback ID: ${contactId}`);
          }

          // Extract groups safely
          let groupDisplay = "No Group";
          let groupsArray = [];

          const possibleGroupFields = ['groups', 'group', 'groupName', 'contactGroup', 'category'];

          for (const field of possibleGroupFields) {
            if (contact[field]) {
              if (Array.isArray(contact[field])) {
                const validGroups = contact[field].filter(group =>
                  availableGroups.some(availGroup =>
                    availGroup.toLowerCase() === String(group).toLowerCase()
                  )
                );

                if (validGroups.length > 0) {
                  groupsArray = validGroups;
                  groupDisplay = validGroups.join(", ");
                  break;
                }
              } else if (typeof contact[field] === 'string') {
                const groupNames = contact[field].split(",").map(g => g.trim());
                const validGroups = groupNames.filter(group =>
                  availableGroups.some(availGroup =>
                    availGroup.toLowerCase() === group.toLowerCase()
                  )
                );

                if (validGroups.length > 0) {
                  groupsArray = validGroups;
                  groupDisplay = validGroups.join(", ");
                  break;
                }
              }
            }
          }

          // Get phone number
          let phoneNumber = "";
          const possiblePhoneFields = ['contactNumber', 'phoneNumber', 'mobileNumber', 'phone', 'mobile', 'number'];

          for (const field of possiblePhoneFields) {
            if (contact[field]) {
              phoneNumber = String(contact[field]);
              break;
            }
          }

          // Get contact name
          const possibleNameFields = ['contactName', 'name', 'firstName', 'firstname', 'fullName', 'fullname', 'profileName'];
          let contactName = contact.contactName || contact.name || "Unnamed";

          for (const field of possibleNameFields) {
            if (contact[field]) {
              contactName = contact[field];
              break;
            }
          }

          // Convert tags to string
          const tagsToString = (tags) => {
            if (!tags) return "";
            if (Array.isArray(tags)) return tags.join(", ");
            if (typeof tags === 'string') return tags;
            return String(tags);
          };

          // Extract user attributes
          const userAttributesObj = {};
          if (userAttributesData) {
            userAttributesData.forEach(attr => {
              if (attr.key !== "contactName" && attr.key !== "name") {
                userAttributesObj[attr.key] = contact[attr.key] || "-";
              }
            });
          }

          // Add API ID to the contact object for reference
          const transformedContact = {
            id: contactId,
            apiId: apiId, // Store the original API ID separately
            name: contactName,
            number: phoneNumber,
            group: groupDisplay,
            groupsArray: groupsArray,
            tags: tagsToString(contact.tags) || "-",
            // Add user attributes
            ...userAttributesObj
          };

          // Skip if this contact ID has already been processed
          if (uniqueContactIds.has(contactId)) {
            console.warn(`Duplicate contact detected: ${contactId}`);
            return;
          }

          uniqueContactIds.add(contactId);
          transformedContacts.push(transformedContact);
        });

        // Set contacts only if the transformed data is different from current contacts
        setContacts(prevContacts => {
          // Check if the new data is different from current
          if (JSON.stringify(prevContacts) !== JSON.stringify(transformedContacts)) {
            return transformedContacts;
          }
          return prevContacts;
        });
      } else {
        setContacts([]);
      }
    } else if (!contactsLoading && !contactsData) {
      setContacts([]);
    }
  }, [contactsData, groupsData, contactsLoading, contactsError, isAuthenticated, availableGroups, userAttributesData]);

  // Handle authentication errors
  useEffect(() => {
    if (contactsError?.status === 403 || groupsError?.status === 403) {
      console.error("Authentication error - Token might be expired or invalid");

      localStorage.removeItem("loginData");
      setIsAuthenticated(false);

      enqueueSnackbar("Your session has expired. Please login again.", {
        variant: "error",
        autoHideDuration: 3000,
      });

      setTimeout(() => {
        navigate("/login");
      }, 2000);
    }
  }, [contactsError, groupsError, navigate, enqueueSnackbar]);

  const convertTagsToString = (tags) => {
    if (!tags) return "";
    if (Array.isArray(tags)) return tags.join(", ");
    if (typeof tags === 'string') return tags;
    return String(tags);
  };

  const downloadCSV = (data, filename) => {
    if (data instanceof Blob) {
      const url = window.URL.createObjectURL(data);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } else if (Array.isArray(data)) {
      const csvContent = convertToCSV(data);
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    }
  };

  const convertToCSV = (data) => {
    if (!data || data.length === 0) return '';

    // Get user attribute keys
    const userAttrHeaders = userAttributesData ?
      userAttributesData.map(attr => attr.key.startsWith('$') ? attr.key : `${attr.key}`) :
      [];

    const headers = [
      'S.No',
      'Contact Name',
      'Mobile Number',
      'Group Name',
      'Tags',
      ...userAttrHeaders
    ];

    const rows = data.map((contact, index) => {
      const userAttrValues = userAttributesData ?
        userAttributesData.map(attr => `"${contact[attr.key] || ''}"`) :
        [];

      return [
        index + 1,
        `"${contact.name || ''}"`,
        `"${contact.number || ''}"`,
        `"${contact.group || ''}"`,
        `"${contact.tags || ''}"`,
        ...userAttrValues
      ];
    });

    const csvArray = [headers.join(','), ...rows.map(row => row.join(','))];
    return csvArray.join('\n');
  };

  const generateCSVForSelectedContacts = (selectedContactsData) => {
    if (!selectedContactsData || selectedContactsData.length === 0) return '';

    // Get user attribute keys
    const userAttrHeaders = userAttributesData ?
      userAttributesData.map(attr => attr.key.startsWith('$') ? attr.key : `${attr.key}`) :
      [];

    const headers = [
      'S.No.',
      'Contact Name',
      'Group Name',
      'Tags',
      'Mobile Number',
      ...userAttrHeaders
    ];

    const rows = selectedContactsData.map((contact, index) => {
      const userAttrValues = userAttributesData ?
        userAttributesData.map(attr => `"${contact[attr.key] || ''}"`) :
        [];

      return [
        index + 1,
        `"${contact.name || ''}"`,
        `"${contact.group || ''}"`,
        `"${contact.tags || ''}"`,
        `"${contact.number || ''}"`,
        ...userAttrValues
      ];
    });

    const csvArray = [headers.join(','), ...rows.map(row => row.join(','))];
    return csvArray.join('\n');
  };

  const openModal = (type, contact = null) => {
    // console.log(contact, 'fdfd')
    if (type === "edit" && contact) {
      setEditingContact(contact);

      // console.log("Edit contact object:", contact);
      // console.log("Contact ID:", contact.id);

      let countryCode = "+" + (contact.countryCode || "91");
      let mobileNumber = contact.phoneNumber || "";

      if (!mobileNumber && contact.number) {
        const fullNumber = contact.number;
        // Attempt to smartly extract country code if full number starts with a code
        const possibleCountryCode = (contact.countryCode || "91").toString();
        if (fullNumber.startsWith(possibleCountryCode)) {
          mobileNumber = fullNumber.substring(possibleCountryCode.length);
        } else {
          mobileNumber = fullNumber;
        }
      }

      let groupValue = "";
      if (contact.groupsArray && contact.groupsArray.length > 0) {
        groupValue = contact.groupsArray.join(", ");
      } else if (contact.group && contact.group !== "No Group") {
        groupValue = contact.group;
      }

      let tagsValue = convertTagsToString(contact.tags);

      // Extract user attributes for form data
      const userAttrData = {};
      if (userAttributesData) {
        userAttributesData.forEach(attr => {
          userAttrData[attr.key] = contact[attr.key] || "";
        });
      }

      setFormData({
        group: groupValue,
        countryCode,
        mobileNumber,
        contactName: contact.name || "",
        tags: tagsValue,
        ...userAttrData
      });
    }

    if ((type === "move" || type === "copy") && contact) {
      if (type === "move") {
        setMoveData({
          currentGroup: contact.group || "",
          availableGroups: "",
          contactId: contact.id // Use the reliable ID
        });
      } else {
        setCopyData({
          availableGroups: "",
          contactId: contact.id, // Use the reliable ID
          currentGroups: contact.group || ""
        });
      }
    }

    if (type === "delete" && selectedContacts.length === 0 && contact) {
      setSelectedContacts([contact.id]); // Use the reliable ID
    }

    setModalType(type);
  };

  const closeModal = () => {
    setModalType(null);
    setEditingContact(null);
    if (modalType === "delete") {
      setSelectedContacts([]);
    }
    resetForms();
  };

  const handleSelectAll = (e) => {
    if (e.target.checked) {
      // select all available ids
      const allContactIds = contacts.map(c => c.id);
      setSelectedContacts(allContactIds);
    } else {
      setSelectedContacts([]);
    }
  };

  const handleSelectContact = (e, id) => {
    if (e.target.checked) {
      setSelectedContacts(prev => [...prev, id]);
    } else {
      setSelectedContacts(prev => prev.filter(contactId => contactId !== id));
    }
  };

  const openBulkDeleteModal = () => {
    if (selectedContacts.length > 0) {
      setIsBulkDeleteModalOpen(true);
    } else {
      enqueueSnackbar("Please select at least one contact to delete.", { variant: "warning" });
    }
  };

  const closeBulkDeleteModal = () => {
    setIsBulkDeleteModalOpen(false);
  };

  const handleBulkDelete = async () => {
    try {
      // Partition into valid mongo ids and invalid ones
      const validIds = selectedContacts.filter(id => /^[0-9a-fA-F]{24}$/.test(id));
      const invalidIds = selectedContacts.filter(id => !/^[0-9a-fA-F]{24}$/.test(id));

      if (validIds.length === 0) {
        enqueueSnackbar("No valid contact IDs were available to delete via API.", { variant: "error" });
        closeBulkDeleteModal();
        return;
      }

      await deleteContacts({ ids: validIds }).unwrap();

      // Update local state by filtering out successfully deleted IDs
      setContacts(prev => prev.filter(c => !validIds.includes(c.id)));
      setSelectedContacts([]);

      enqueueSnackbar(
        `${validIds.length} contact(s) deleted successfully!`,
        { variant: "success" }
      );
      closeBulkDeleteModal();
      refetchContacts();

      // if (invalidIds.length > 0) {
      //   enqueueSnackbar(
      //     `Some selections could not be deleted via API (invalid or temporary IDs): ${invalidIds.join(", ")}`,
      //     { variant: "warning", autoHideDuration: 6000 }
      //   );
      // }
    } catch (error) {
      console.error("Delete error:", error);
      enqueueSnackbar("Failed to delete contacts", { variant: "error" });
    }
  };

  const resetForms = () => {
    setFormData({
      group: "",
      countryCode: "+91",
      mobileNumber: "",
      contactName: "",
      tags: "",
    });
    setMoveData({
      currentGroup: "",
      availableGroups: "",
      contactId: null
    });
    setCopyData({
      availableGroups: "",
      contactId: null,
      currentGroups: ""
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleMoveChange = (e) => {
    const { name, value } = e.target;
    setMoveData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCopyChange = (e) => {
    const { name, value } = e.target;
    setCopyData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const validateContactForm = () => {
    if (!formData.contactName.trim()) {
      enqueueSnackbar("Contact name is required!", { variant: "error" });
      return false;
    }
    if (!formData.mobileNumber.trim()) {
      enqueueSnackbar("Mobile number is required!", { variant: "error" });
      return false;
    }
    if (!formData.group.trim()) {
      enqueueSnackbar("Group is required!", { variant: "error" });
      return false;
    }

    const cleanNumber = formData.mobileNumber.replace(/\D/g, '');
    if (cleanNumber.length !== 10) {
      enqueueSnackbar("Please enter a valid 10-digit mobile number!", { variant: "error" });
      return false;
    }

    return true;
  };

  const validateMoveForm = () => {
    if (!moveData.availableGroups) {
      enqueueSnackbar("Please select a group to move to!", { variant: "error" });
      return false;
    }
    return true;
  };

  const validateCopyForm = () => {
    if (!copyData.availableGroups) {
      enqueueSnackbar("Please select a group to copy to!", { variant: "error" });
      return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      switch (modalType) {
        case "add":
          if (validateContactForm()) {
            // Extract user attributes from formData
            const userAttributesPayload = {};
            if (userAttributesData) {
              userAttributesData.forEach(attr => {
                userAttributesPayload[attr.key] = formData[attr.key] || "";
              });
            }

            const contactData = {
              contactName: formData.contactName,
              countryCode: formData.countryCode.replace(/^\+/, ""),
              phoneNumber: formData.mobileNumber.replace(/\D/g, ""),
              groups: formData.group.split(",").map(g => g.trim()).filter(Boolean),
              tags: formData.tags.split(",").map(t => t.trim()).filter(Boolean),
              ...userAttributesPayload
            };
            await createContact(contactData).unwrap();
            enqueueSnackbar("Contact added successfully!", { variant: "success" });
            closeModal();
            refetchContacts();
            refetchGroups();
          }
          break;

        case "edit":
          if (validateContactForm() && editingContact) {
            // console.log("Editing contact object:", editingContact);

            // Try multiple ID sources in order of preference
            let contactId = null;

            // Option 1: Try to get a valid MongoDB ID from the original contact data
            if (contactsData?.data && Array.isArray(contactsData.data)) {
              const originalContact = contactsData.data.find(c => {
                // Match by phone number and name
                const phoneMatch = (c.contactNumber || c.phoneNumber || c.mobileNumber || c.number) === editingContact.number;
                const nameMatch = (c.contactName || c.name) === editingContact.name;
                return phoneMatch && nameMatch;
              });

              if (originalContact) {
                contactId = originalContact._id || originalContact.id || originalContact.contactId;
                // console.log("Found original contact with ID:", contactId);
              }
            }

            // Option 2: Use the apiId stored in transformed contact
            if (!contactId && editingContact.apiId && /^[0-9a-fA-F]{24}$/.test(editingContact.apiId)) {
              contactId = editingContact.apiId;
              // console.log("Using valid apiId from transformed contact:", contactId);
            }

            // Option 3: Use the id from transformed contact if it looks valid
            if (!contactId && editingContact.id && editingContact.id !== "." && /^[0-9a-fA-F]{24}$/.test(editingContact.id)) {
              contactId = editingContact.id;
              // console.log("Using id from transformed contact:", contactId);
            }

            if (!contactId) {
              console.error("Could not find valid contact ID for editing");
              enqueueSnackbar("Cannot edit contact: Invalid or missing contact ID", { variant: "error" });
              break;
            }

            // Validate it's a MongoDB ID
            if (!/^[0-9a-fA-F]{24}$/.test(contactId)) {
              console.warn("Contact ID doesn't look like MongoDB ID:", contactId);
              // You might want to still try if your API accepts other formats
            }

            const tagsArray = formData.tags
              ? formData.tags.split(",").map(t => t.trim()).filter(Boolean)
              : [];

            const RESERVED_KEYS = ["id", "_id", "contactId", "createdAt", "updatedAt"];
            const userAttributesPayload = {};

            if (userAttributesData) {
              userAttributesData.forEach(attr => {
                if (!RESERVED_KEYS.includes(attr.key)) {
                  userAttributesPayload[attr.key] = formData[attr.key] || "";
                }
              });
            }
            const contactPayload = {
              contactName: formData.contactName,
              countryCode: formData.countryCode.replace(/^\+/, ""),
              phoneNumber: formData.mobileNumber.replace(/\D/g, ""),
              groups: formData.group.split(",").map(g => g.trim()).filter(Boolean),
              tags: tagsArray,
              ...userAttributesPayload
            };

            // console.log("Sending edit request with ID:", contactId, "and payload:", contactPayload);

            try {
              await editContact({
                id: contactId,
                contact: contactPayload,
                body: {
                  id: contactId,           // 👈 include ID in request body
                  contact: contactPayload  // 👈 backend expects this format
                }
              }).unwrap();

              enqueueSnackbar("Contact updated successfully!", { variant: "success" });
              closeModal();
              refetchContacts();
              refetchGroups();
            } catch (error) {
              enqueueSnackbar(error?.data?.msg || "Failed to update contact", { variant: "error" });
            }
          }
          break;


        case "move":
          if (validateMoveForm() && moveData.contactId) {
            let contactId = moveData.contactId;

            // 🔍 Try to resolve invalid temporary IDs
            if (!/^[0-9a-fA-F]{24}$/.test(contactId)) {
              const original = contactsData?.data?.find(
                c =>
                  (c.contactName === editingContact?.name ||
                    c.name === editingContact?.name) &&
                  (c.phoneNumber === editingContact?.number ||
                    c.contactNumber === editingContact?.number)
              );
              contactId = original?._id || original?.id || contactId;
            }

            if (!/^[0-9a-fA-F]{24}$/.test(contactId)) {
              enqueueSnackbar("Could not determine valid contact ID for move", { variant: "error" });
              break;
            }

            try {
              await moveContactToGroup({
                contactId: contactId,
                currentGroups: moveData.currentGroup.split(",").map(g => g.trim()).filter(Boolean),
                targetGroup: moveData.availableGroups
              }).unwrap();

              enqueueSnackbar("Contact moved successfully!", { variant: "success" });
              closeModal();
              refetchContacts();
              refetchGroups();
            } catch (error) {
              console.error("Move contact error:", error);
              enqueueSnackbar(error?.data?.msg || "Failed to move contact", { variant: "error" });
            }
          }
          break;


        case "copy":
          if (validateCopyForm() && copyData.contactId) {
            let contactId = copyData.contactId;

            // 🔍 Resolve invalid IDs
            if (!/^[0-9a-fA-F]{24}$/.test(contactId)) {
              const original = contactsData?.data?.find(
                c =>
                  (c.contactName === editingContact?.name ||
                    c.name === editingContact?.name) &&
                  (c.phoneNumber === editingContact?.number ||
                    c.contactNumber === editingContact?.number)
              );
              contactId = original?._id || original?.id || contactId;
            }

            if (!/^[0-9a-fA-F]{24}$/.test(contactId)) {
              enqueueSnackbar("Could not determine valid contact ID for copy", { variant: "error" });
              break;
            }

            try {
              await copyContact({
                contactId: contactId,
                targetGroup: copyData.availableGroups
              }).unwrap();

              enqueueSnackbar("Contact copied successfully!", { variant: "success" });
              closeModal();
              refetchContacts();
              refetchGroups();
            } catch (error) {
              console.error("Copy contact error:", error);
              enqueueSnackbar(error?.data?.msg || "Failed to copy contact", { variant: "error" });
            }
          }
          break;


        case "delete":
          if (selectedContacts.length > 0) {
            try {
              // selectedContacts contains the best available IDs
              const idsToAttempt = selectedContacts.slice(); // copy

              // Keep only non-null values
              const nonEmpty = idsToAttempt.filter(Boolean);

              // Partition into valid mongo ids and invalid ones
              const validIds = nonEmpty.map(id => {
                if (/^[0-9a-fA-F]{24}$/.test(id)) return id;
                const original = contactsData?.data?.find(
                  c =>
                    (c.contactName === contacts.find(co => co.id === id)?.name ||
                      c.name === contacts.find(co => co.id === id)?.name) &&
                    (c.phoneNumber === contacts.find(co => co.id === id)?.number ||
                      c.contactNumber === contacts.find(co => co.id === id)?.number)
                );
                return original?._id || original?.id || null;
              }).filter(Boolean);
              const invalidIds = nonEmpty.filter(id => !/^[0-9a-fA-F]{24}$/.test(id));

              if (validIds.length === 0) {
                // Nothing valid to send to API
                enqueueSnackbar("No valid contact IDs were available to delete via API.", { variant: "error" });
                closeModal();
                break;
              }

              // delete only valid ones
              await deleteContacts({ ids: validIds }).unwrap();

              // remove deleted contacts from local state
              setContacts(prev => prev.filter(c => !validIds.includes(c.id)));

              // clear selected contacts that were deleted
              setSelectedContacts(prev => prev.filter(sid => !validIds.includes(sid)));

              enqueueSnackbar(`${validIds.length} contact(s) deleted successfully!`, { variant: "success" });
              closeModal();
              refetchContacts();
              refetchGroups();

              // if (invalidIds.length > 0) {
              //   enqueueSnackbar(
              //     `Some selections could not be deleted via API (invalid or temporary IDs): ${invalidIds.join(", ")}`,
              //     { variant: "warning", autoHideDuration: 6000 }
              //   );
              // }
            } catch (error) {
              console.error("Delete error:", error);
              enqueueSnackbar(error?.data?.msg || "Failed to delete contact", { variant: "error" });
            }
          }
          break;

        default:
          break;
      }
    } catch (error) {
      console.error("Operation error:", error);
      enqueueSnackbar(error?.data?.msg || error?.data?.error || "Operation failed. Please try again.", { variant: "error" });
    }
  };

  const handleExportContact = async (contactId) => {
    if (!isAuthenticated) {
      enqueueSnackbar("Please log in to export contacts", { variant: "error" });
      return;
    }

    // FIX: Reliable ID validation for export API
    if (!contactId || !/^[0-9a-fA-F]{24}$/.test(contactId)) {
      enqueueSnackbar("Invalid contact ID. Falling back to local export.", { variant: "warning" });
      // Fall through to local export logic below
    } else {
      try {
        // Try API export first
        const result = await exportOneContact(contactId).unwrap();

        // If API returns a blob, download it
        if (result instanceof Blob) {
          const contact = contacts.find(c => c.id === contactId);
          const contactName = contact?.name?.replace(/[^a-zA-Z0-9]/g, '_') || 'contact';
          const filename = `contact_${contactName}_${new Date().toISOString().split('T')[0]}.csv`;
          downloadCSV(result, filename);
          enqueueSnackbar("Contact exported successfully!", { variant: "success" });
          return; // API export succeeded, so exit
        }
        // If API did not return a blob, fall through to local export (e.g., if API returned JSON data)

      } catch (error) {
        console.error("API Export error, falling back to local:", error);
        enqueueSnackbar("API export failed. Exporting locally.", { variant: "warning" });
        // Fall through to local export logic
      }
    }

    // Fallback/Local Export logic
    const contact = contacts.find(c => c.id === contactId);
    if (contact) {
      const csvData = convertToCSV([contact]);
      const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
      const contactName = contact.name?.replace(/[^a-zA-Z0-9]/g, '_') || 'contact';
      const filename = `contact_${contactName}_${new Date().toISOString().split('T')[0]}.csv`;
      downloadCSV(blob, filename);
      enqueueSnackbar("Contact exported locally!", { variant: "success" });
    } else {
      enqueueSnackbar("Export failed: Contact not found locally.", { variant: "error" });
    }
  };

  const handleExportAllContacts = async () => {
    if (!contacts || contacts.length === 0) {
      enqueueSnackbar("No contacts to export", { variant: "warning" });
      return;
    }

    if (!isAuthenticated) {
      enqueueSnackbar("Please log in to export contacts", { variant: "error" });
      return;
    }

    try {
      // Generate CSV locally
      const csvContent = generateCSVForSelectedContacts(contacts);
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `all_contacts_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      enqueueSnackbar(
        `${contacts.length} contact(s) exported successfully!`,
        { variant: "success" }
      );
    } catch (error) {
      console.error("Export all error:", error);
      enqueueSnackbar("Failed to export contacts", { variant: "error" });
    }
  };

  const handleExportSelectedContacts = async () => {
    if (selectedContacts.length === 0) {
      enqueueSnackbar("Please select at least one contact to export.", { variant: "warning" });
      return;
    }

    if (!isAuthenticated) {
      enqueueSnackbar("Please log in to export contacts", { variant: "error" });
      return;
    }

    try {
      const selectedContactsData = contacts.filter(contact =>
        selectedContacts.includes(contact.id)
      );
      const csvContent = generateCSVForSelectedContacts(selectedContactsData);
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `selected_contacts_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      enqueueSnackbar(
        `${selectedContacts.length} contact(s) exported successfully!`,
        { variant: "success" }
      );
    } catch (error) {
      console.error("Export error:", error);
      enqueueSnackbar("Failed to export contacts", { variant: "error" });
    }
  };

  const isAllSelected = selectedContacts.length === contacts.length && contacts.length > 0;

  if (!isAuthenticated) {
    return (
      <MasterLayout>
        <Breadcrumb title="Contact Group" />
        <div className="text-center p-4">
          <Icon icon="mdi:alert-circle" style={{ fontSize: '48px', color: '#faad14' }} className="mb-3" />
          <h5 className="text-warning mb-3">Authentication Required</h5>
          <p className="mb-3">Please log in to view contacts.</p>
          <button
            className="btn-primary"
            onClick={() => navigate("/login")}
          >
            Go to Login
          </button>
        </div>
      </MasterLayout>
    );
  }

  if (contactsError || groupsError) {
    let errorMessage = "Unknown error";

    if (contactsError?.data || groupsError?.data) {
      const errorData = contactsError?.data || groupsError?.data;
      if (typeof errorData === 'string') {
        errorMessage = errorData;
      } else if (errorData.error) {
        errorMessage = errorData.error;
      } else if (errorData.msg) {
        errorMessage = errorData.msg;
      } else if (errorData.message) {
        errorMessage = errorData.message;
      }
    } else if (contactsError?.error || groupsError?.error) {
      errorMessage = contactsError?.error || groupsError?.error;
    } else if (contactsError?.message || groupsError?.message) {
      errorMessage = contactsError?.message || groupsError?.message;
    } else if (contactsError?.status || groupsError?.status) {
      const status = contactsError?.status || groupsError?.status;
      errorMessage = `HTTP Error: ${status}`;
    }

    return (
      <MasterLayout>
        <Breadcrumb title="Contact Group" />
        <div className="text-center p-4">
          <Icon icon="mdi:alert-circle" style={{ fontSize: '48px', color: '#ff4d4f' }} className="mb-3" />
          <h5 className="text-danger mb-3">Error Loading Contacts</h5>
          <p className="mb-3">{errorMessage}</p>
          <div className="d-flex gap-2 justify-content-center">
            <button className="btn-primary" onClick={() => {
              refetchContacts();
              refetchGroups();
            }}>
              <Icon icon="mdi:refresh" style={{ marginRight: '8px' }} />
              Retry
            </button>
            <button className="btn-secondary" onClick={() => navigate("/login")}>
              Re-login
            </button>
          </div>
        </div>
      </MasterLayout>
    );
  }

  if (contactsLoading || groupsLoading) {
    return (
      <MasterLayout>
        <Breadcrumb title="Contact Group" />
        <div className="text-center p-4">
          <Icon icon="mdi:loading" className="spin" style={{ fontSize: '48px' }} />
          <p className="mt-3">Loading contacts...</p>
        </div>
      </MasterLayout>
    );
  }

  return (
    <MasterLayout>
      <Breadcrumb title="Contact Group" />
      <div>
        <div className="d-flex justify-content-end align-items-center mb-4 p-12">
          {/* Action buttons */}
          <div className="d-flex align-items-center gap-8">
            <button
              className="d-flex align-items-center justify-content-center"
              onClick={() => openModal("add")}
              title="Add Contact"
            >
              <Icon icon="icon-park-outline:add" style={{ fontSize: "24px" }} />
            </button>

            <button
              className="d-flex align-items-center justify-content-center"
              onClick={openBulkDeleteModal}
              title="Delete Selected"
              style={{
                fontSize: "24px",
                color: selectedContacts.length > 0 ? '#ff4d4f' : '',
              }}
              disabled={selectedContacts.length === 0}
            >
              <Icon
                icon="icon-park-outline:delete"
                style={{ fontSize: "24px" }}
              />
            </button>

            <button
              className="d-flex align-items-center justify-content-center"
              onClick={() => setShowImportModal(true)}
              title="Import Contacts"
              style={{
                border: "none",
                background: "transparent",
                cursor: "pointer",
              }}
            >
              <Icon icon="gg:import" style={{ fontSize: "24px" }} />
            </button>

            <button
              className="d-flex align-items-center justify-content-center"
              onClick={handleExportSelectedContacts}
              title={selectedContacts.length > 0 ? `Export ${selectedContacts.length} selected contact(s)` : "Export Selected"}
              style={{
                border: "none",
                background: "transparent",
                cursor: selectedContacts.length > 0 ? "pointer" : "not-allowed",
                opacity: selectedContacts.length > 0 ? 1 : 0.5
              }}
              disabled={selectedContacts.length === 0}
            >
              <Icon
                icon="gg:export"
                style={{
                  fontSize: "24px",
                  color: selectedContacts.length > 0 ? '' : '#ccc'
                }}
              />
            </button>

            <button className="btn-primary d-flex align-items-center gap-2" onClick={() => navigate("/managegroups")}>
              <Icon
                style={{ fontSize: "20px" }}
                icon="mingcute:group-fill"
              />
              Manage Groups
            </button>

            <button
              className="btn-primary d-flex align-items-center gap-2"
              onClick={handleExportAllContacts}
              disabled={!contacts || contacts.length === 0}
            >
              <Icon
                style={{ fontSize: "20px" }}
                icon="typcn:download"
              />
              Sample CSV File
            </button>
          </div>
        </div>

        {/* Contacts Table */}
        <div className="card basic-data-table">
          <div className="card-body">
            <div className="table-responsive">
              <table className="table bordered-table mb-0">
                <thead>
                  <tr>
                    <th scope="col" style={{ width: "50px" }}>
                      <div className="form-check style-check d-flex align-items-center">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          checked={isAllSelected}
                          onChange={handleSelectAll}
                          disabled={contacts.length === 0}
                        />
                      </div>
                    </th>
                    <th scope="col">S.No.</th>
                    <th scope="col">Contact Name</th>
                    <th scope="col">Group Name</th>
                    <th scope="col">Tags</th>
                    <th scope="col">Mobile Number</th>
                    {/* Add headers for user attributes */}
                    {userAttributesData && userAttributesData.length > 0 && (
                      userAttributesData.map((attr) => (
                        <th scope="col" key={attr.key}>
                          {attr.key.startsWith('$') ? attr.key : `${attr.key}`}
                        </th>
                      ))
                    )}
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {contacts.length > 0 ? (
                    contacts.map((contact, index) => (
                      <tr key={`${contact.id}-${index}`}>
                        <td>
                          <div className="form-check style-check d-flex align-items-center">
                            <input
                              className="form-check-input"
                              type="checkbox"
                              checked={selectedContacts.includes(contact.id)}
                              onChange={(e) => handleSelectContact(e, contact.id)}
                            />
                          </div>
                        </td>
                        <td>{index + 1}</td>
                        <td>{contact.name}</td>
                        <td>
                          <span className="badge bg-primary" style={{ fontSize: "14px" }}>
                            {contact.group}
                          </span>
                        </td>
                        <td>
                          <span className="badge bg-primary" style={{ fontSize: "14px" }}>
                            {contact.tags || "-"}
                          </span>
                        </td>
                        <td>{contact.number}</td>
                        {/* Add user attributes data columns */}
                        {userAttributesData && userAttributesData.length > 0 && (
                          userAttributesData.map((attr) => (
                            <td key={attr.key}>
                              {contact[attr.key] || "-"}
                            </td>
                          ))
                        )}
                        <td>
                          <div className="d-flex align-items-center gap-2">
                            <button
                              className="w-32-px h-32-px bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                              onClick={() => openModal("edit", contact)}
                              title="Edit"
                            >
                              <Icon icon="lucide:edit" style={{ fontSize: 16 }} />
                            </button>

                            <button
                              className="w-32-px h-32-px bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                              onClick={() => openModal("move", contact)}
                              title="Move"
                            >
                              <Icon icon="lets-icons:move-alt" style={{ fontSize: 16 }} />
                            </button>

                            <button
                              className="w-32-px h-32-px bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                              onClick={() => openModal("copy", contact)}
                              title="Copy"
                            >
                              <Icon icon="nimbus:copy" style={{ fontSize: 16 }} />
                            </button>

                            <button
                              className="w-32-px h-32-px bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                              onClick={() => handleExportContact(contact.id)}
                              title="Export"
                            >
                              <Icon icon="gg:export" style={{ fontSize: 16 }} />
                            </button>

                            <button
                              className="w-32-px h-32-px bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                              onClick={() => openModal("delete", contact)}
                              title="Delete"
                            >
                              <Icon icon="mingcute:delete-2-line" style={{ fontSize: 16 }} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6 + (userAttributesData ? userAttributesData.length : 0)} className="text-center py-4">
                        <div className="d-flex flex-column align-items-center">
                          <Icon icon="mdi:account-multiple-outline" style={{ fontSize: '48px', color: '#ccc', marginBottom: '16px' }} />
                          <p className="text-muted mb-0">No contacts found</p>
                          <p className="text-muted">Click the + button to add your first contact</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Contact Action Modal */}
        <ContactActionModal
          modalType={modalType}
          onClose={closeModal}
          onSubmit={handleSubmit}
          formData={formData}
          moveData={moveData}
          copyData={copyData}
          onInputChange={handleInputChange}
          onMoveChange={handleMoveChange}
          onCopyChange={handleCopyChange}
          availableGroups={availableGroups}
        />

        {/* Import Contacts Modal */}
        <ImportContactsModal
          isOpen={showImportModal}
          onClose={() => setShowImportModal(false)}
          onImportSuccess={() => {
            refetchContacts();
            refetchGroups();
            enqueueSnackbar("Contacts imported successfully!", { variant: "success" });
          }}
        />

        {/* Bulk Delete Modal */}
        {isBulkDeleteModalOpen && (
          <div className="modal-overlay">
            <div className="modal-content" style={{ width: "500px" }}>
              <div className="modal-body">
                <div className="d-flex align-items-center mb-3">
                  <Icon icon="clarity:warning-line" color="#faad14" style={{ fontSize: '24px', marginRight: '8px' }} />
                  <h6 className="mb-0">Are you sure you want to delete these {selectedContacts.length} contacts?</h6>
                </div>
                <p className="text-muted mb-4">
                  This action cannot be undone.
                </p>
                <div className="d-flex justify-content-end gap-3">
                  <button
                    className="btn-secondary"
                    onClick={closeBulkDeleteModal}
                  >
                    No, cancel
                  </button>
                  <button
                    className="btn-primary"
                    onClick={handleBulkDelete}
                  >
                    Yes, delete
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </MasterLayout>
  );
};

export default Contacts;