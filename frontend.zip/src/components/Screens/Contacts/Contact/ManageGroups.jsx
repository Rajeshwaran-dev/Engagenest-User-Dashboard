import React, { useState, useEffect } from "react";
import "datatables.net-dt/js/dataTables.dataTables.js";
import { Icon } from "@iconify/react/dist/iconify.js";
import { Link, useNavigate } from "react-router-dom";
import MasterLayout from "../../../../masterLayout/MasterLayout";
import Breadcrumb from "../../../Breadcrumb";
import GroupActionModal from "../Modules/GroupActionModal";
import { useSnackbar } from "notistack";
import {
  useGetAllContactGroupsQuery,
  useCreateContactGroupMutation,
  useEditGroupMutation,
  useDeleteGroupMutation,
  useMoveOneContactMutation,
  useCopyGroupMutation,
  useGetAllContactsQuery
} from "../../../../store/ApiFilesV2/ContactApis";

const ManageGroups = () => {
  const navigate = useNavigate();
  const { enqueueSnackbar } = useSnackbar();

  // ... existing state and hooks remain exactly the same
  const { data: groupsData, isLoading, refetch: refetchGroups } = useGetAllContactGroupsQuery();
  const [createContactGroup] = useCreateContactGroupMutation();
  const [editGroup] = useEditGroupMutation();
  const [deleteGroup] = useDeleteGroupMutation();
  const [moveOneContact] = useMoveOneContactMutation();
  const [copyGroup] = useCopyGroupMutation();

  const [modalType, setModalType] = useState(null);
  const [groups, setGroups] = useState([]);
  const [editingGroup, setEditingGroup] = useState(null);

  const [formData, setFormData] = useState({
    groupName: "",
  });

  const [moveData, setMoveData] = useState({
    currentGroup: "",
    availableGroups: "",
    groupId: null
  });

  const [copyData, setCopyData] = useState({
    sourceGroup: "",
    groupId: null
  });

  const { data: allContactsData } = useGetAllContactsQuery({
    offset: 0,
    limit: 10000,
  });

  // ============ EXPORT LOGIC STARTS HERE ============
  
  // Function to download CSV file
  const downloadCSVFile = (csvContent, filename) => {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  // Function to generate CSV for groups
  const generateGroupCSV = (groupsData) => {
    if (!groupsData || groupsData.length === 0) return '';
    
    const headers = [
      'Name',
      'Country Code',
      'Contact Number',
      'Group',
      'UserName',
      'Blocked Status',
      'Created At'
    ];
    
    const allContactsForExport = [];
    
    groupsData.forEach(group => {
      let contactsArray = [];
      
      if (allContactsData) {
        if (Array.isArray(allContactsData)) {
          contactsArray = allContactsData;
        } else if (allContactsData?.data && Array.isArray(allContactsData.data)) {
          contactsArray = allContactsData.data;
        } else if (allContactsData?.contacts && Array.isArray(allContactsData.contacts)) {
          contactsArray = allContactsData.contacts;
        }
      }
      
      const groupContacts = contactsArray.filter(contact => {
        let contactGroups = [];
        const possibleGroupFields = ['groups', 'group', 'groupName', 'contactGroup', 'category'];
        
        for (const field of possibleGroupFields) {
          if (contact[field]) {
            if (Array.isArray(contact[field])) {
              contactGroups = contact[field];
              break;
            } else if (typeof contact[field] === 'string') {
              contactGroups = contact[field].split(',').map(g => g.trim());
              break;
            }
          }
        }
        
        return contactGroups.includes(group.name);
      });
      
      groupContacts.forEach(contact => {
        let contactName = "Unknown";
        const possibleNameFields = ['contactName', 'name', 'firstName', 'firstname', 'fullName', 'fullname'];
        
        for (const field of possibleNameFields) {
          if (contact[field]) {
            contactName = contact[field];
            break;
          }
        }
        
        let phoneNumber = "";
        const possiblePhoneFields = ['contactNumber', 'phoneNumber', 'mobileNumber', 'phone', 'mobile', 'number'];
        
        for (const field of possiblePhoneFields) {
          if (contact[field]) {
            phoneNumber = String(contact[field]);
            break;
          }
        }
        
        const row = [
          `"${contactName}"`,
          "91",
          `"${phoneNumber}"`,
          `"${group.name}"`,
          "undefined",
          "No",
          new Date().toLocaleDateString('en-GB')
        ];
        
        allContactsForExport.push(row);
      });
    });
    
    if (allContactsForExport.length === 0) {
      groupsData.forEach(group => {
        const row = [
          `"Group: ${group.name}"`,
          "91",
          `"N/A"`,
          `"${group.name}"`,
          "undefined",
          "No",
          new Date().toLocaleDateString('en-GB')
        ];
        allContactsForExport.push(row);
      });
    }
    
    const csvArray = [headers.join(','), ...allContactsForExport.map(row => row.join(','))];
    return csvArray.join('\n');
  };

  // Function to export a single group
  const handleExportGroup = async (group) => {
    try {
      const csvContent = generateGroupCSV([group]);
      const groupName = group.name?.replace(/[^a-zA-Z0-9]/g, '_') || 'group';
      downloadCSVFile(csvContent, `${groupName}_contacts_${new Date().toISOString().split('T')[0]}.csv`);
      
      enqueueSnackbar(`${group.name} contacts exported successfully!`, { variant: "success" });
    } catch (error) {
      console.error("Group export error:", error);
      enqueueSnackbar("Failed to export group contacts", { variant: "error" });
    }
  };

  
  // ============ EXPORT LOGIC ENDS HERE ============

  // ... REST OF YOUR EXISTING CODE REMAINS EXACTLY THE SAME
  // Transform API data - NO CHANGES
  useEffect(() => {
    if (groupsData?.data && allContactsData) {
      let contactsArray = [];

      if (Array.isArray(allContactsData)) {
        contactsArray = allContactsData;
      } else if (allContactsData?.data && Array.isArray(allContactsData.data)) {
        contactsArray = allContactsData.data;
      } else if (allContactsData?.contacts && Array.isArray(allContactsData.contacts)) {
        contactsArray = allContactsData.contacts;
      }

      const groupContactCounts = {};

      contactsArray.forEach(contact => {
        let contactGroups = [];
        const possibleGroupFields = ['groups', 'group', 'groupName', 'contactGroup', 'category'];

        for (const field of possibleGroupFields) {
          if (contact[field]) {
            if (Array.isArray(contact[field])) {
              contactGroups = contact[field];
              break;
            } else if (typeof contact[field] === 'string') {
              contactGroups = contact[field].split(',').map(g => g.trim());
              break;
            }
          }
        }

        contactGroups.forEach(groupName => {
          if (groupName) {
            groupContactCounts[groupName] = (groupContactCounts[groupName] || 0) + 1;
          }
        });
      });

      const transformedGroups = groupsData.data.map(group => {
        const groupName = group.name;
        return {
          id: group._id || group.id,
          name: groupName,
          totalContacts: groupContactCounts[groupName] || 0
        };
      });

      setGroups(transformedGroups);
    } else if (groupsData?.data) {
      const transformedGroups = groupsData.data.map(group => ({
        id: group._id || group.id,
        name: group.name,
        totalContacts: group.contactCount || 0
      }));
      setGroups(transformedGroups);
    }
  }, [groupsData, allContactsData]);

  // All other functions remain EXACTLY the same - NO CHANGES
  const openModal = (type, group = null) => {
    if (type === "edit" && group) {
      setEditingGroup(group);
      setFormData({
        groupName: group.name || ""
      });
    }

    if ((type === "move" || type === "copy" || type === "delete") && group) {
      setMoveData({
        currentGroup: group.name || "",
        availableGroups: "",
        groupId: group.id
      });
    }

    setModalType(type);
  };

  const closeModal = () => {
    setModalType(null);
    setEditingGroup(null);
    resetForms();
  };

  const resetForms = () => {
    setFormData({
      groupName: "",
    });
    setMoveData({
      currentGroup: "",
      availableGroups: "",
      groupId: null
    });
    setCopyData({
      sourceGroup: "",
      groupId: null
    });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleMoveChange = (e) => {
    const { name, value } = e.target;
    setMoveData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleCopyChange = (e) => {
    const { name, value } = e.target;
    setCopyData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      switch (modalType) {
        case "edit":
          if (editingGroup) {
            await editGroup({
              id: editingGroup.id,
              name: formData.groupName
            }).unwrap();
            enqueueSnackbar("Group updated successfully!", { variant: "success" });
            closeModal();
            refetchGroups();
          }
          break;

        case "move":
          if (moveData.groupId && moveData.availableGroups) {
            await moveOneContact({
              currentGroup: moveData.currentGroup,
              newGroup: moveData.availableGroups
            }).unwrap();
            enqueueSnackbar("Group moved successfully!", { variant: "success" });
            closeModal();
            refetchGroups();
          }
          break;

        case "copy":
          if (moveData.groupId && copyData.sourceGroup) {
            await copyGroup({
              currentGroup: moveData.currentGroup,
              sourceGroup: copyData.sourceGroup
            }).unwrap();
            enqueueSnackbar("Contacts copied successfully!", { variant: "success" });
            closeModal();
            refetchGroups();
          }
          break;

        case "delete":
          if (moveData.groupId) {
            await deleteGroup({ id: moveData.groupId }).unwrap();
            enqueueSnackbar("Group deleted successfully!", { variant: "success" });
            closeModal();
            refetchGroups();
          }
          break;

        default:
          break;
      }
    } catch (error) {
      enqueueSnackbar("Operation failed. Please try again.", { variant: "error" });
    }
  };

  const availableGroups = groups.map(group => group.name).filter(name => name !== moveData.currentGroup);

  if (isLoading) {
    return (
      <MasterLayout>
        <Breadcrumb title="Manage Groups" />
        <div className="text-center p-4">Loading groups...</div>
      </MasterLayout>
    );
  }

  return (
    <MasterLayout>
      <Breadcrumb title="Manage Groups" />

      <div className="d-flex justify-content-between align-items-center mb-4 p-12">
        <div className="d-flex align-items-center gap-3">
          <div className="position-relative">
            <input
              type="text"
              className="form-control form-control-sm ps-5"
              placeholder="Search Group"
            />
            <Icon
              icon="eva:search-fill"
              className="position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"
              style={{ fontSize: "18px" }}
            />
          </div>
        </div>

        <div className="d-flex align-items-center gap-3">
          <button
            className="btn-primary d-flex align-items-center gap-2"
            onClick={() => navigate("/contact")}
          >
            <Icon
              style={{ fontSize: "20px" }}
              icon="mingcute:group-fill"
            />
            Manage Contacts
          </button>
        </div>
      </div>

      <div className="card basic-data-table">
        <div className="card-body">
          <div className="table-responsive">
            <table className="table bordered-table mb-0">
              <thead>
                <tr>
                  <th scope="col">S.No.</th>
                  <th scope="col">Group Name</th>
                  <th scope="col">Total Contacts</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {groups.map((group, index) => (
                  <tr key={group.id}>
                    <td>
                      <div className="form-check style-check d-flex align-items-center">
                        <label className="form-check-label">{index + 1}</label>
                      </div>
                    </td>
                    <td>{group.name}</td>
                    <td>{group.totalContacts}</td>
                    <td>
                      <div className="d-flex">
                        <button
                          className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                          onClick={() => openModal("edit", group)}
                        >
                          <Icon icon="lucide:edit" />
                        </button>
                        <button
                          className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                          onClick={() => openModal("move", group)}
                        >
                          <Icon icon="lets-icons:move-alt" />
                        </button>
                        <button
                          className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                          onClick={() => openModal("copy", group)}
                        >
                          <Icon icon="nimbus:copy" />
                        </button>
                        {/* Only change: Add onClick handler to existing export button */}
                        <button
                          className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                          onClick={() => handleExportGroup(group)}
                        >
                          <Icon icon="gg:export" />
                        </button>
                        <button
                          className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                          onClick={() => openModal("delete", group)}
                        >
                          <Icon icon="mingcute:delete-2-line" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {groups.length === 0 && (
                  <tr>
                    <td colSpan="4" className="text-center py-4">No groups found.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <GroupActionModal
        modalType={modalType}
        onClose={closeModal}
        onSubmit={handleSubmit}
        formData={formData}
        moveData={moveData}
        copyData={copyData}
        onInputChange={handleInputChange}
        onMoveChange={handleMoveChange}
        onCopyChange={handleCopyChange}
        availableGroups={availableGroups}
      />
    </MasterLayout>
  );
};

export default ManageGroups;