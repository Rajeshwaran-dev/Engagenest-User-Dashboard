import React, { useState, useEffect, useCallback } from "react";
import { useSnackbar } from "notistack";
import {
  useGetUserAttrQuery,
} from "../../../../store/ApiFilesV2/UserApis";
import {
  useGetAllContactGroupsQuery,
  useImportContactsMutation,
} from "../../../../store/ApiFilesV2/ContactApis";
import {
  useGetCsvHeadersMutation,
} from "../../../../store/ApiFilesV2/FileHandlerApis";
import { Icon } from "@iconify/react/dist/iconify.js";
import _ from "lodash";

const ImportContactModel = ({
  isOpen,
  onClose,
  onImportSuccess,
}) => {
  const { enqueueSnackbar } = useSnackbar();

  // States
  const [formData, setFormData] = useState({
    group: "",
    headers: [],
    fileUrl: "",
    contactName: "",
    countryCode: "",
    phoneNumber: "",
  });

  const [previewData, setPreviewData] = useState([]);
  const [userAttributes, setUserAttributes] = useState([]);
  const [fileUploaded, setFileUploaded] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasInvalidContacts, setHasInvalidContacts] = useState(false);
  const [csvHeaders, setCsvHeaders] = useState([]);
  const [availableGroups, setAvailableGroups] = useState([]);
  const [fileList, setFileList] = useState([]);
  
  // NEW: Add columns state for dynamic table structure
  const [columns, setColumns] = useState({
    columns: [],
    data: [],
  });

  // Get API URL
  const getApiUrl = () => {
    if (typeof process.env !== 'undefined' && process.env && process.env.REACT_APP_API_URL) {
      return process.env.REACT_APP_API_URL;
    }
    else if (process.env.REACT_APP_API_URL) {
      return process.env.REACT_APP_API_URL;
    }
    else {
      console.warn("No API URL found in environment variables. Using relative URL.");
      return "/api/";
    }
  };

  const API_URL = getApiUrl();

  // API hooks
  const { data: userAttributesData } = useGetUserAttrQuery();
  const { data: groupsData } = useGetAllContactGroupsQuery();
  const [getCsvHeaders] = useGetCsvHeadersMutation();
  const [importContacts] = useImportContactsMutation();

  // Extract available groups
  useEffect(() => {
    if (groupsData?.data) {
      setAvailableGroups(groupsData.data.map(group => ({
        value: group.name || group.id || "",
        label: group.name || "Unnamed Group"
      })));
    }
  }, [groupsData]);

  // NEW: Structure columns with dynamic user attributes (from old code)
  const structureColumnsWithDynamicUsrAttr = useCallback(() => {
    const baseColumns = [
      { title: "Contact Name", dataIndex: "contactName" },
      { title: "Country Code", dataIndex: "countryCode" },
      { title: "Phone Number", dataIndex: "phoneNumber" },
    ];

    if (userAttributes.length > 0) {
      const attrColumns = userAttributes.map(attr => ({
        title: attr.displayName || attr.key,
        dataIndex: attr.key,
      }));
      
      setColumns(prev => ({
        ...prev,
        columns: [...baseColumns, ...attrColumns],
      }));
    } else {
      setColumns(prev => ({
        ...prev,
        columns: baseColumns,
      }));
    }
  }, [userAttributes]);

  // Extract user attributes and initialize formData with dynamic keys
  useEffect(() => {
    if (userAttributesData) {
      const attrs = Array.isArray(userAttributesData)
        ? userAttributesData
        : userAttributesData?.data || [];

      setUserAttributes(attrs.map(attr => ({
        key: attr.key,
        displayName: attr.val || attr.key,
        mappedTo: "",
      })));

      // Initialize formData with all user attribute keys
      setFormData(prev => {
        const newFormData = { ...prev };
        attrs.forEach(attr => {
          if (!newFormData.hasOwnProperty(attr.key)) {
            newFormData[attr.key] = "";
          }
        });
        return newFormData;
      });
    }
  }, [userAttributesData]);

  // NEW: Update columns structure when userAttributes change
  useEffect(() => {
    if (userAttributes.length > 0) {
      structureColumnsWithDynamicUsrAttr();
    }
  }, [userAttributes, structureColumnsWithDynamicUsrAttr]);

  // Reset function
  const resetAll = () => {
    const baseFormData = {
      group: "",
      headers: [],
      fileUrl: "",
      contactName: "",
      countryCode: "",
      phoneNumber: "",
    };

    userAttributes.forEach(attr => {
      baseFormData[attr.key] = "";
    });

    setFormData(baseFormData);
    setFileList([]);
    setPreviewData([]);
    setCsvHeaders([]);
    setFileUploaded(false);
    setHasInvalidContacts(false);
    
    // NEW: Reset columns data
    setColumns(prev => ({
      ...prev,
      data: [],
    }));
  };

  // Handle file upload
  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) {
      console.error("No file selected");
      return;
    }

    if (!file.name.toLowerCase().endsWith('.csv')) {
      enqueueSnackbar("Please upload a CSV file", {
        variant: "error",
        autoHideDuration: 3000,
      });
      event.target.value = null;
      return;
    }

    setIsLoading(true);
    setFileList([{ name: file.name, status: 'uploading' }]);

    try {
      const uploadFormData = new FormData();
      uploadFormData.append('file', file);

      const loginDetails = JSON.parse(localStorage.getItem("loginData"));
      const token = loginDetails?.token;

      if (!token) {
        throw new Error("No authentication token found");
      }

      const uploadEndpoint = "filehandler/upload/temp";
      const uploadUrl = `${API_URL}${uploadEndpoint}`.replace(/([^:]\/)\/+/g, "$1");

      const uploadResponse = await fetch(uploadUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: uploadFormData
      });

      if (!uploadResponse.ok) {
        const errorText = await uploadResponse.text();
        console.error("Upload error response:", errorText);
        throw new Error(`Upload failed with status ${uploadResponse.status}`);
      }

      const uploadResult = await uploadResponse.json();
      const fileUrl = uploadResult?.fileUrl || uploadResult?.data?.fileUrl || uploadResult?.url;

      if (!fileUrl) {
        throw new Error("File upload failed - no URL returned");
      }

      setFileList([{ name: file.name, status: 'done' }]);

      const headersResult = await getCsvHeaders({
        url: fileUrl,
      }).unwrap();

      let headers = headersResult?.data?.data || headersResult?.data || headersResult || [];

      if (!Array.isArray(headers)) {
        if (typeof headers === 'string') {
          headers = headers.split(',').map(h => h.trim());
        } else {
          headers = [];
        }
      }

      if (headers.length === 0) {
        throw new Error("No headers found in CSV file");
      }

      setCsvHeaders(headers);

      const newFormData = {
        group: formData.group,
        headers: headers,
        fileUrl: fileUrl,
        contactName: "",
        countryCode: "",
        phoneNumber: "",
      };

      userAttributes.forEach(attr => {
        newFormData[attr.key] = "";
      });

      setFormData(newFormData);

      setUserAttributes(prev =>
        prev.map(attr => ({
          ...attr,
          mappedTo: "",
        }))
      );

      setFileUploaded(true);
      setPreviewData([]);
      setHasInvalidContacts(false);
      
      // NEW: Clear columns data on new file upload
      setColumns(prev => ({
        ...prev,
        data: [],
      }));

      enqueueSnackbar("File uploaded successfully! Now map your CSV columns.", {
        variant: "success",
        autoHideDuration: 3000,
      });

    } catch (error) {
      console.error("File upload error details:", error);

      let errorMessage = "Failed to upload file";
      if (error.message) {
        errorMessage += ": " + error.message;
      }

      enqueueSnackbar(errorMessage, {
        variant: "error",
        autoHideDuration: 5000,
      });

      setFileList([]);
      setFileUploaded(false);
      event.target.value = null;
    } finally {
      setIsLoading(false);
    }
  };

  // Handle form field changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  // Handle user attribute mapping
  const handleUserAttributeMapping = (attrKey, csvHeader) => {
    setUserAttributes(prev =>
      prev.map(attr =>
        attr.key === attrKey ? { ...attr, mappedTo: csvHeader } : attr
      )
    );

    setFormData(prev => ({
      ...prev,
      [attrKey]: csvHeader,
    }));
  };

  // Transform headers
  const transformHeaders = (header) => {
    return header.trim().replace(/\s+/g, "_").toLowerCase();
  };

  // UPDATED: Handle preview with data population (from old code)
  const handlePreview = async () => {
    // Validate required fields
    if (!formData.group || formData.group.trim() === "") {
      enqueueSnackbar("Please select a group", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    if (!formData.contactName || formData.contactName.trim() === "") {
      enqueueSnackbar("Please select Contact Name field from CSV", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    if (!formData.countryCode || formData.countryCode.trim() === "") {
      enqueueSnackbar("Please select Country Code field from CSV", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    if (!formData.phoneNumber || formData.phoneNumber.trim() === "") {
      enqueueSnackbar("Please select Phone Number field from CSV", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    if (!formData.fileUrl) {
      enqueueSnackbar("No file uploaded", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    setIsLoading(true);
    try {
      const reformedFormData = JSON.parse(JSON.stringify(formData));
      delete reformedFormData.headers;
      delete reformedFormData.fileUrl;

      console.log("Preview mapings:", reformedFormData);
      console.log("Preview fileUrl:", formData.fileUrl);

      const previewResult = await importContacts({
        fileUrl: formData.fileUrl,
        mapings: reformedFormData,
        mode: "preview",
      }).unwrap();

      console.log("Full Preview result:", JSON.stringify(previewResult, null, 2));

      // Try multiple possible response structures
      let data = null;
      let contacts = [];
      let invalidContacts = [];
      
      // Check different possible response structures
      if (previewResult?.data?.data) {
        data = previewResult.data.data;
        console.log("Data found at: previewResult.data.data");
      } else if (previewResult?.data) {
        data = previewResult.data;
        console.log("Data found at: previewResult.data");
      } else if (previewResult) {
        data = previewResult;
        console.log("Data found at: previewResult");
      }

      if (data) {
        contacts = data?.contacts || [];
        invalidContacts = data?.invalidContacts || [];
        console.log("Contacts found:", contacts.length);
        console.log("Invalid contacts found:", invalidContacts.length);
        console.log("Sample contact:", JSON.stringify(contacts[0], null, 2));
        console.log("Sample invalid contact:", JSON.stringify(invalidContacts[0], null, 2));
      }

      const allContacts = [...contacts, ...invalidContacts];
      
      // Log the keys of the first contact to see what's actually in the data
      if (allContacts.length > 0) {
        console.log("=== CONTACT DATA ANALYSIS ===");
        console.log("Available keys in contact data:", Object.keys(allContacts[0]));
        console.log("Full first contact:", JSON.stringify(allContacts[0], null, 2));
        console.log("All contacts:", JSON.stringify(allContacts, null, 2));
        
        // Check each key's value
        Object.keys(allContacts[0]).forEach(key => {
          console.log(`${key}:`, allContacts[0][key]);
        });
      }

      if (allContacts.length === 0) {
        console.error("No contacts found in response. Full response:", previewResult);
        enqueueSnackbar("No contacts found in the preview. Check console for details.", {
          variant: "warning",
          autoHideDuration: 3000,
        });
        return;
      }

      // IMPORTANT FIX: Normalize the API response data to match our expected format
      // The API returns: contactNumber, but we use: phoneNumber
      const normalizedContacts = allContacts.map(contact => {
        const normalized = { ...contact };
        
        // Map API keys to our expected keys
        if (contact.contactNumber !== undefined) {
          normalized.phoneNumber = contact.contactNumber;
        }
        if (contact.contactName === undefined && contact.name !== undefined) {
          normalized.contactName = contact.name;
        }
        
        // Check if this contact has an error
        if (contact.error) {
          normalized._hasError = true;
          normalized._errorMessage = contact.error;
        }
        
        return normalized;
      });

      // Update both previewData and columns.data
      setPreviewData(normalizedContacts);
      setColumns(prev => ({
        ...prev,
        data: normalizedContacts,
      }));

      console.log("Updated columns.data with", normalizedContacts.length, "contacts");
      console.log("Normalized first contact:", JSON.stringify(normalizedContacts[0], null, 2));
      
      // Count contacts with errors
      const errorCount = normalizedContacts.filter(c => c._hasError).length;
      console.log("Contacts with errors:", errorCount);

      setHasInvalidContacts(invalidContacts.length > 0);

      if (invalidContacts.length > 0) {
        enqueueSnackbar(
          `Uploaded File has Invalid country code. Fix it to enable the import button.`,
          {
            variant: "error",
            autoHideDuration: 3000,
          }
        );
      } else {
        enqueueSnackbar(
          previewResult?.data?.msg || `Preview loaded successfully! Found ${contacts.length} contacts.`,
          {
            variant: "success",
            autoHideDuration: 3000,
          }
        );
      }
    } catch (error) {
      console.error("Preview error:", error);
      console.error("Error details:", JSON.stringify(error, null, 2));

      let errorMessage = "Failed to load preview";
      if (error.message) {
        errorMessage += ": " + error.message;
      } else if (error?.data?.message) {
        errorMessage += ": " + error.data.message;
      }

      enqueueSnackbar(errorMessage, {
        variant: "error",
        autoHideDuration: 5000,
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle import
  const handleImport = async () => {
    if (hasInvalidContacts) {
      enqueueSnackbar(
        "There are invalid contacts in the uploaded file. Please fix them before importing.",
        {
          variant: "error",
          autoHideDuration: 3000,
        }
      );
      return;
    }

    if (!formData.group || formData.group.trim() === "") {
      enqueueSnackbar("Please select a group", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    if (previewData.length === 0) {
      enqueueSnackbar("Please view preview before importing", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    setIsLoading(true);
    try {
      const reformedFormData = JSON.parse(JSON.stringify(formData));
      delete reformedFormData.headers;
      delete reformedFormData.fileUrl;

      const importResult = await importContacts({
        fileUrl: formData.fileUrl,
        mapings: reformedFormData,
        mode: "save",
      }).unwrap();

      enqueueSnackbar("Contacts imported successfully!", {
        variant: "success",
        autoHideDuration: 3000,
      });

      if (onImportSuccess) {
        onImportSuccess();
      }

      handleClose();
    } catch (error) {
      console.error("Import error:", error);

      let errorMessage = "Failed to import contacts";
      if (error.message) {
        errorMessage += ": " + error.message;
      } else if (error?.data?.message) {
        errorMessage += ": " + error.data.message;
      }

      enqueueSnackbar(errorMessage, {
        variant: "error",
        autoHideDuration: 5000,
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Reset file
  const resetFile = () => {
    const newFormData = {
      group: formData.group,
      headers: [],
      fileUrl: "",
      contactName: "",
      countryCode: "",
      phoneNumber: "",
    };

    userAttributes.forEach(attr => {
      newFormData[attr.key] = "";
    });

    setFormData(newFormData);

    setUserAttributes(prev =>
      prev.map(attr => ({
        ...attr,
        mappedTo: "",
      }))
    );

    setCsvHeaders([]);
    setFileUploaded(false);
    setFileList([]);
    setPreviewData([]);
    setHasInvalidContacts(false);
    
    // NEW: Clear columns data
    setColumns(prev => ({
      ...prev,
      data: [],
    }));

    const fileInput = document.querySelector('input[type="file"]');
    if (fileInput) {
      fileInput.value = null;
    }
  };

  // Reset form
  const resetForm = () => {
    resetAll();
  };

  // Handle close
  const handleClose = () => {
    resetForm();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div
      className="modal-overlay"
      style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
      tabIndex="-1"
    >
      <div className="modal-content" style={{ width: "1200px", maxHeight: "90vh" }}>
        <div className="modal-header">
          <div className="d-flex align-items-center">
            <div>
              <Icon
                className="modal-icon-adjustments"
                icon="hugeicons:contact-book"
              />
            </div>
            <h3
              className="modal-title"
              style={{ marginTop: "2px", marginLeft: "10px" }}
            >
              Import Contacts from CSV
            </h3>
          </div>
          <button
            type="button"
            className="btn-close"
            onClick={handleClose}
            disabled={isLoading}
          >
            <Icon icon="mingcute:close-line" />
          </button>
        </div>

        <div className="modal-body p-30" style={{ overflowY: "auto", maxHeight: "calc(90vh - 150px)" }}>
          <div className="row">
            {/* Step 1: Group Selection */}
            <div className="col-md-6 mb-4">
              <label className="form-label fw-semibold text-dark required">
                Group
              </label>
              <select
                className="form-select"
                name="group"
                value={formData.group}
                onChange={handleInputChange}
                required
                disabled={isLoading}
              >
                <option value="">Select Group</option>
                {availableGroups.map((group, index) => (
                  <option key={index} value={group.value}>
                    {group.label}
                  </option>
                ))}
              </select>
            </div>

            {/* Step 2: File Upload */}
            <div className="col-md-6 mb-4">
              <label className="form-label fw-semibold text-dark required">
                Choose CSV File
              </label>
              <div className="input-group">
                <input
                  type="file"
                  className="form-control"
                  accept=".csv"
                  onChange={handleFileUpload}
                  disabled={isLoading}
                  key={fileUploaded ? "uploaded" : "empty"}
                />
                {fileUploaded && (
                  <span className="input-group-text text-success">
                    <Icon icon="mdi:check-circle" />
                  </span>
                )}
              </div>
              {fileList.length > 0 && (
                <div className="mt-2">
                  <small className="text-muted">
                    File: {fileList[0].name} ({fileList[0].status === 'uploading' ? 'Uploading...' : 'Uploaded'})
                  </small>
                </div>
              )}
            </div>

            {/* Required Fields Mapping */}
            <div className="col-md-4 mb-4">
              <label className="form-label fw-semibold text-dark required">
                Contact Name Field
              </label>
              <select
                className="form-select"
                name="contactName"
                value={formData.contactName}
                onChange={handleInputChange}
                disabled={isLoading || !csvHeaders.length}
              >
                <option value="">Select CSV Column</option>
                {csvHeaders.map((header, index) => (
                  <option key={index} value={header}>
                    {header}
                  </option>
                ))}
              </select>
            </div>

            <div className="col-md-4 mb-4">
              <label className="form-label fw-semibold text-dark required">
                Country Code Field
              </label>
              <select
                className="form-select"
                name="countryCode"
                value={formData.countryCode}
                onChange={handleInputChange}
                disabled={isLoading || !csvHeaders.length}
              >
                <option value="">Select CSV Column</option>
                {csvHeaders.map((header, index) => (
                  <option key={index} value={header}>
                    {header}
                  </option>
                ))}
              </select>
            </div>

            <div className="col-md-4 mb-4">
              <label className="form-label fw-semibold text-dark required">
                Mobile Number Field
              </label>
              <select
                className="form-select"
                name="phoneNumber"
                value={formData.phoneNumber}
                onChange={handleInputChange}
                disabled={isLoading || !csvHeaders.length}
              >
                <option value="">Select CSV Column</option>
                {csvHeaders.map((header, index) => (
                  <option key={index} value={header}>
                    {header}
                  </option>
                ))}
              </select>
            </div>

            {/* Custom Attributes Mapping */}
            {userAttributes.length > 0 && (
              <>
                <div className="col-12 mb-2 mt-4">
                  <h6 className="text-primary">Custom Attributes (Optional)</h6>
                </div>
                {userAttributes.map((attr) => (
                  <div className="col-md-4 mb-3" key={attr.key}>
                    <label className="form-label fw-semibold text-dark">
                      {attr.displayName}
                    </label>
                    <select
                      className="form-select"
                      value={formData[attr.key] || ""}
                      onChange={(e) => handleUserAttributeMapping(attr.key, e.target.value)}
                      disabled={isLoading || !csvHeaders.length}
                    >
                      <option value=""></option>
                      {csvHeaders.map((header, index) => (
                        <option key={index} value={header}>
                          {header}
                        </option>
                      ))}
                    </select>
                  </div>
                ))}
              </>
            )}

            {/* Action Buttons */}
            <div className="col-12 mt-4">
              <div className="d-flex gap-2">
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handlePreview}
                  disabled={isLoading || !fileUploaded}
                >
                  {isLoading ? (
                    <>
                      <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                      Processing...
                    </>
                  ) : (
                    "View Preview"
                  )}
                </button>

                <button
                  type="button"
                  className="btn-secondary"
                  onClick={resetFile}
                  disabled={isLoading || !fileUploaded}
                >
                  Reset File
                </button>
              </div>
            </div>

            {/* Debug Info - Remove after testing */}
            {csvHeaders.length > 0 && (
              <div className="col-12 mt-3">
                <div className="alert alert-info">
                  <small>
                    <strong>Debug Info:</strong><br/>
                    Preview Data Length: {previewData.length}<br/>
                    Columns Data Length: {columns.data.length}<br/>
                    Columns Structure Length: {columns.columns.length}<br/>
                    Has Invalid Contacts: {hasInvalidContacts ? 'Yes' : 'No'}<br/>
                    {columns.data.length > 0 && (
                      <>
                        <br/><strong>Sample Contact Keys:</strong><br/>
                        {Object.keys(columns.data[0] || {}).join(', ')}<br/>
                        <br/><strong>Expected Column Keys:</strong><br/>
                        {columns.columns.map(c => c.dataIndex).join(', ')}
                      </>
                    )}
                  </small>
                </div>
              </div>
            )}

            {/* UPDATED: Dynamic Preview Table (from old code) */}
            {columns.data.length > 0 && (
              <div className="col-12 mt-4">
                <div className="border rounded p-4 bg-light">
                  <h6 className="mb-3">Preview ({columns.data.length} contacts)</h6>
                  <div className="table-responsive" style={{ maxHeight: "400px", overflow: "auto" }}>
                    <table className="table table-bordered table-sm table-hover">
                      <thead className="table-light sticky-top">
                        <tr>
                          {columns.columns.map((col, index) => (
                            <th key={index} style={{ minWidth: "150px" }}>
                              {col.title}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {columns.data.map((contact, rowIndex) => (
                          <tr 
                            key={rowIndex}
                            className={contact._hasError ? 'table-danger' : ''}
                            title={contact._hasError ? contact._errorMessage : ''}
                          >
                            {columns.columns.map((col, colIndex) => {
                              // Special handling for phoneNumber - it might be duplicated
                              let value;
                              
                              if (col.dataIndex === 'phoneNumber') {
                                // For phone number, prefer contactNumber, then phoneNumber
                                value = contact.contactNumber || contact.phoneNumber;
                              } else if (col.dataIndex === 'contactName') {
                                // For contact name, try multiple possible keys
                                value = contact.contactName || contact.name || contact.Name;
                              } else {
                                // Try multiple possible key formats for other fields
                                value = contact[col.dataIndex] 
                                  || contact[col.dataIndex?.toLowerCase()] 
                                  || contact[col.dataIndex?.toUpperCase()];
                              }
                              
                              // Clean up the value - remove undefined text
                              if (value === 'undefined' || value === undefined || value === null || value === '') {
                                value = '-';
                              }
                              
                              return (
                                <td key={colIndex}>
                                  {value}
                                </td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <div className="form-text mt-2">
                    {hasInvalidContacts ? (
                      <span className="text-danger">
                        ⚠️ Some contacts have invalid country codes. Please fix the CSV file.
                      </span>
                    ) : (
                      <span className="text-success">
                        ✓ All {columns.data.length} contacts are valid and ready for import.
                      </span>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="modal-footer border-0 bg-light">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={handleClose}
            disabled={isLoading}
          >
            Cancel
          </button>
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleImport}
            disabled={isLoading || hasInvalidContacts || columns.data.length === 0}
          >
            {isLoading ? (
              <>
                <span className="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
                Importing...
              </>
            ) : (
              "Import Contacts"
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ImportContactModel;