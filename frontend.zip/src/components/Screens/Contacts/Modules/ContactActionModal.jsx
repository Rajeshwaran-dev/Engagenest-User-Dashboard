import React, { useState, useEffect } from "react";
import { Icon } from "@iconify/react/dist/iconify.js";
import { useGetUserAttrQuery } from "../../../../store/ApiFilesV2/UserApis";

const ContactActionModal = ({
  modalType,
  onClose,
  onSubmit,
  formData,
  moveData,
  copyData,
  onInputChange,
  onMoveChange,
  onCopyChange,
  availableGroups: propAvailableGroups = [],
  editingContact = null
}) => {
  const [showTagsDropdown, setShowTagsDropdown] = useState(false);
  const [tagsInput, setTagsInput] = useState("");
  const [availableTags, setAvailableTags] = useState([]);
  const [userAttributes, setUserAttributes] = useState({});

  // Fetch user attributes
  const { data: userAttributesData } = useGetUserAttrQuery();

  const predefinedTags = ["New", "Important", "VIP", "Regular", "Priority", "Urgent"];

  useEffect(() => {
    if (modalType === "add" || modalType === "edit") {
      setTagsInput("");

      // Initialize available tags from formData
      const tags = formData.tags ? formData.tags.split(",").map(tag => tag.trim()).filter(tag => tag) : [];
      setAvailableTags(tags);

      // Process user attributes data
      if (userAttributesData) {
        const attributesObj = {};
        userAttributesData.forEach(attr => {
          attributesObj[attr.key] = {
            key: attr.key,
            // NAME column: Use the key (with $ prefix if not already present)
            name: attr.key.startsWith('$') ? attr.key : `$${attr.key}`,
            // VALUE column: Store for reference
            displayName: attr.val || attr.key,
            value: formData[attr.key] || ""
          };
        });
        setUserAttributes(attributesObj);
      }
    }
  }, [modalType, formData.tags, userAttributesData, formData]);

  if (!modalType) return null;

  const handleTagsInputChange = (e) => {
    const value = e.target.value;
    setTagsInput(value);
    setShowTagsDropdown(true);
  };

  const handleTagsKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addTag(tagsInput);
    }
  };

  const addTag = (value) => {
    const trimmed = String(value || "").trim();
    if (!trimmed) return;

    const exists = availableTags.some(
      tag => tag.toLowerCase() === trimmed.toLowerCase()
    );
    if (exists) {
      setTagsInput("");
      setShowTagsDropdown(false);
      return;
    }

    const newTags = [...availableTags, trimmed];
    setAvailableTags(newTags);

    onInputChange({
      target: {
        name: "tags",
        value: newTags.join(", ")
      }
    });

    setTagsInput("");
    setShowTagsDropdown(false);
  };

  const handleRemoveTag = (tagToRemove) => {
    const newTags = availableTags.filter(tag => tag !== tagToRemove);
    setAvailableTags(newTags);

    onInputChange({
      target: {
        name: "tags",
        value: newTags.join(", ")
      }
    });
  };

  const filteredTagSuggestions = predefinedTags.filter(
    item => item.toLowerCase().includes(tagsInput.toLowerCase()) &&
      !availableTags.includes(item)
  );

  const handleUserAttributeChange = (attrKey, value) => {
    setUserAttributes(prev => ({
      ...prev,
      [attrKey]: {
        ...prev[attrKey],
        value: value
      }
    }));

    onInputChange({
      target: {
        name: attrKey,
        value: value
      }
    });
  };

  const renderUserAttributesSection = () => {
    if (!userAttributesData || userAttributesData.length === 0) return null;

    return (
      <div className="row mb-4">
        <div className="col-12 p-0">
          <h6 className="mb-3">Custom Attributes</h6>
          <div className="row">
            {userAttributesData.map((attr, index) => (
              <div className="col-md-6 mb-3" key={attr.key}>
                {/* Show NAME column data: the key with $ prefix */}
                <label className="form-label fw-semibold text-dark">
                  {attr.key.startsWith('$') ? attr.key : `${attr.key}`}
                </label>
                <input
                  type="text"
                  className="form-control"
                  value={userAttributes[attr.key]?.value || ""}
                  onChange={(e) => handleUserAttributeChange(attr.key, e.target.value)}
                  placeholder={`Enter ${attr.key.startsWith('$') ? attr.key : `${attr.key}`}`}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  };

  const renderModalContent = () => {
    switch (modalType) {
      case "add":
      case "edit":
        return (
          <div className="modal-content" style={{ width: "800px" }}>
            <div className="modal-header">
              <div className="d-flex align-items-center">
                <div>
                  <Icon
                    className="modal-icon-adjustments"
                    icon="hugeicons:contact-book"
                  />
                </div>
                <h3
                  className="modal-title"
                  style={{ marginTop: "2px", marginLeft: "10px" }}
                >
                  {modalType === "add" ? "Add Contact" : "Edit Contact"}
                </h3>
              </div>
              <button
                type="button"
                className="btn-close"
                onClick={onClose}
              >
                <Icon icon="mingcute:close-line" />
              </button>
            </div>
            <div className="modal-body p-30">
              <div>
                <div className="mb-4">
                  <label
                    style={{ color: "var(--text-secondary)" }}
                    htmlFor="group"
                    className="form-label fw-semibold text-dark"
                  >
                    Group <span className="text-danger">*</span>
                  </label>
                  <select
                    className="form-select"
                    id="group"
                    name="group"
                    value={formData.group}
                    onChange={onInputChange}
                    required
                  >
                    <option value="">Select Group</option>
                    {propAvailableGroups.map((group, index) => (
                      <option key={index} value={group}>
                        {group}
                      </option>
                    ))}
                  </select>
                  <div className="form-text">
                    Select a group for this contact
                  </div>
                </div>

                <div className="row mb-4">
                  <div className="col-md-4 p-0">
                    <label
                      style={{ color: "var(--text-secondary)" }}
                      htmlFor="countryCode"
                      className="form-label fw-semibold text-dark"
                    >
                      Country Code <span className="text-danger">*</span>
                    </label>
                    <select
                      className="form-select"
                      id="countryCode"
                      name="countryCode"
                      value={formData.countryCode}
                      onChange={onInputChange}
                      required
                    >
                      <option value="+91">+91 (India)</option>
                      <option value="+1">+1 (USA)</option>
                      <option value="+44">+44 (UK)</option>
                      <option value="+61">+61 (Australia)</option>
                    </select>
                  </div>
                  <div className="col-md-8">
                    <label
                      style={{ color: "var(--text-secondary)" }}
                      htmlFor="mobileNumber"
                      className="form-label fw-semibold text-dark"
                    >
                      Mobile Number <span className="text-danger">*</span>
                    </label>
                    <input
                      type="text"
                      className="form-control"
                      id="mobileNumber"
                      name="mobileNumber"
                      value={formData.mobileNumber}
                      onChange={(e) => {
                        const value = e.target.value;
                        if (/^\d*$/.test(value)) {
                          if (value.length <= 10) {
                            onInputChange(e);
                          }
                        }
                      }}
                      placeholder="Mobile number"
                      required
                    />
                    {formData.mobileNumber &&
                      formData.mobileNumber.length !== 10 && (
                        <small style={{ color: "red" }}>
                          Mobile number must be exactly 10 digits
                        </small>
                      )}
                  </div>
                </div>

                <div className="mb-4">
                  <label
                    style={{ color: "var(--text-secondary)" }}
                    htmlFor="contactName"
                    className="form-label fw-semibold text-dark"
                  >
                    Contact Name <span className="text-danger">*</span>
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    id="contactName"
                    name="contactName"
                    value={formData.contactName}
                    onChange={onInputChange}
                    placeholder="Contact Name"
                    required
                  />
                </div>

                <div className="mb-4">
                  <label
                    style={{ color: "var(--text-secondary)" }}
                    htmlFor="tags"
                    className="form-label fw-semibold text-dark"
                  >
                    Tags
                  </label>
                  <div className="position-relative">
                    <div
                      className="d-flex flex-wrap p-2 border rounded position-relative"
                      style={{ minHeight: "48px", alignItems: "center", cursor: "text", gap: "3px" }}
                      onClick={() => {
                        document.getElementById("tagsInput").focus();
                      }}
                    >
                      {availableTags.length > 0 ? (
                        availableTags.map((tag, index) => (
                          <span
                            key={index}
                            style={{
                              fontSize: "15px",
                              display: "inline-flex",
                              alignItems: "center",
                              padding: "6px 10px",
                              borderRadius: "4px",
                              background: "#1f1750",
                              color: "#fff",
                            }}
                          >
                            {tag}
                            <Icon
                              icon="material-symbols:close-rounded"
                              style={{
                                fontSize: "18px",
                                marginLeft: "8px",
                                cursor: "pointer",
                              }}
                              onClick={() => handleRemoveTag(tag)}
                            />
                          </span>
                        ))
                      ) : (
                        <span className="text-muted"></span>
                      )}

                      <input
                        id="tagsInput"
                        type="text"
                        className="form-control"
                        value={tagsInput}
                        onChange={handleTagsInputChange}
                        onKeyDown={handleTagsKeyDown}
                        placeholder="Type and press Enter"
                        style={{
                          border: "none",
                          outline: "none",
                          minWidth: "160px",
                          flex: "1 1 160px",
                          background: "transparent",
                          padding: "6px",
                        }}
                      />

                      {showTagsDropdown && filteredTagSuggestions.length > 0 && (
                        <ul
                          style={{
                            position: "absolute",
                            top: "100%",
                            left: 0,
                            width: "100%",
                            background: "#fff",
                            border: "1px solid #ccc",
                            borderRadius: "4px",
                            marginTop: "2px",
                            padding: "4px 0",
                            listStyle: "none",
                            maxHeight: "160px",
                            overflowY: "auto",
                            zIndex: 1000,
                          }}
                        >
                          {filteredTagSuggestions.map((item, index) => (
                            <li
                              key={index}
                              onClick={() => addTag(item)}
                              style={{
                                padding: "8px 12px",
                                cursor: "pointer",
                                fontSize: "14px",
                              }}
                              onMouseEnter={(e) =>
                                (e.target.style.background = "#f2f2f2")
                              }
                              onMouseLeave={(e) =>
                                (e.target.style.background = "transparent")
                              }
                            >
                              {item}
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>

                {/* User Attributes Section */}
                {renderUserAttributesSection()}
              </div>
            </div>
            <div className="modal-footer border-0 bg-light">
              <button
                type="button"
                className="btn-secondary"
                onClick={onClose}
              >
                Cancel
              </button>
              <button
                type="button"
                className="btn-primary"
                onClick={onSubmit}
              >
                Submit
              </button>
            </div>
          </div>
        );

      // ... rest of the modal types remain the same
      case "move":
        return (
          <div className="modal-content" style={{ width: "500px" }}>
            <div className="modal-header">
              <h3 className="modal-title">Move Contact</h3>
              <button type="button" className="btn-close" onClick={onClose}>
                <Icon icon="mingcute:close-line" />
              </button>
            </div>
            <div className="modal-body p-30">
              <div className="mb-4">
                <label style={{ color: "var(--text-secondary)" }} className="form-label fw-semibold text-dark">
                  Current Groups:
                </label>
                <input
                  type="text"
                  className="form-control"
                  value={moveData.currentGroup}
                  readOnly
                  disabled
                />
              </div>
              <div className="mb-4">
                <label style={{ color: "var(--text-secondary)" }} className="form-label fw-semibold text-dark">
                  Available Groups:
                </label>
                <select
                  className="form-select"
                  name="availableGroups"
                  value={moveData.availableGroups}
                  onChange={onMoveChange}
                >
                  <option value="">Select Group</option>
                  {propAvailableGroups.map((group, index) => (
                    <option key={index} value={group}>
                      {group}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="modal-footer border-0 bg-light">
              <button type="button" className="btn-secondary" onClick={onClose}>
                Cancel
              </button>
              <button type="button" className="btn-primary" onClick={onSubmit}>
                OK
              </button>
            </div>
          </div>
        );

      case "copy":
        return (
          <div className="modal-content" style={{ width: "500px" }}>
            <div className="modal-header">
              <h3 className="modal-title">Copy Contact</h3>
              <button type="button" className="btn-close" onClick={onClose}>
                <Icon icon="mingcute:close-line" />
              </button>
            </div>
            <div className="modal-body p-30">
              <div className="mb-4">
                <label style={{ color: "var(--text-secondary)" }} className="form-label fw-semibold text-dark">
                  Current Groups:
                </label>
                <input
                  type="text"
                  className="form-control"
                  value={copyData.currentGroups}
                  readOnly
                  disabled
                />
              </div>
              <div className="mb-4">
                <label style={{ color: "var(--text-secondary)" }} className="form-label fw-semibold text-dark">
                  Available Groups:
                </label>
                <select
                  className="form-select"
                  name="availableGroups"
                  value={copyData.availableGroups}
                  onChange={onCopyChange}
                >
                  <option value="">Select Group</option>
                  {propAvailableGroups.map((group, index) => (
                    <option key={index} value={group}>
                      {group}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <div className="modal-footer border-0 bg-light">
              <button type="button" className="btn-secondary" onClick={onClose}>
                Cancel
              </button>
              <button type="button" className="btn-primary" onClick={onSubmit}>
                OK
              </button>
            </div>
          </div>
        );

      case "delete":
        return (
          <div className="modal-content" style={{ width: "500px" }}>
            <div className="modal-header">
              <h3 className="modal-title">Delete Confirmation</h3>
              <button type="button" className="btn-close" onClick={onClose}>
                <Icon icon="mingcute:close-line" />
              </button>
            </div>
            <div className="modal-body">
              <div className="">
                <h6 className="mb-3 text-primary-2">
                  Are you sure you want to delete this contact?
                </h6>
              </div>
            </div>
            <div className="modal-footer justify-content-end">
              <button type="button" className="btn-secondary" onClick={onClose}>
                Cancel
              </button>
              <button type="button" className="btn-primary" onClick={onSubmit}>
                Delete
              </button>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div
      className="modal-overlay"
      style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
      tabIndex="-1"
    >
      <div className="modal-content-wrapper">
        {renderModalContent()}
      </div>
    </div>
  );
};

export default ContactActionModal;