import React, { useState, useEffect } from "react";
import { Icon } from "@iconify/react/dist/iconify.js";

const AddEditAgentModal = ({
    showModal,
    handleCancel,
    handleSubmit,
    formData,
    handleInputChange,
    formValid,
    editingIndex,
}) => {
    const [accessTypes, setAccessTypes] = useState({
        chatAgent: false,
        ticketing: false,
        leads: false,
        appointment: false,
    });
    ;

    const [partialAccess, setPartialAccess] = useState(false);
    const [intervene, setIntervene] = useState(false);

    // Initialize access types based on role
    useEffect(() => {
        if (formData.role) {
            updateAccessTypesByRole(formData.role);
        }

        // If editing, load existing data
        if (editingIndex !== null) {
            // This would come from your existing agent data
            // For now, we'll keep the role-based defaults
        }
    }, [formData.role, editingIndex]);

    const updateAccessTypesByRole = (role) => {
        let defaultAccess = {
            chatAgent: false,
            ticketing: false,
            leads: false,
            appointment: false,
        };

        switch (role) {
            case "Agent":
                // Agent: Only Chat Agent is available (but OFF by default)
                defaultAccess.chatAgent = false;
                defaultAccess.ticketing = false;
                defaultAccess.leads = false;
                defaultAccess.appointment = false;
                break;
            case "Super Agent":
                // Super Agent: Chat Agent + Ticketing available (but OFF by default)
                defaultAccess.chatAgent = false;
                defaultAccess.ticketing = false;
                defaultAccess.leads = false;
                defaultAccess.appointment = false;
                break;
            case "Admin":
                // Admin: All types available (but OFF by default)
                defaultAccess.chatAgent = false;
                defaultAccess.ticketing = false;
                defaultAccess.leads = false;
                defaultAccess.appointment = false;
                break;
            default:
                break;
        }

        setAccessTypes(defaultAccess);
    };

    const handleRoleChange = (e) => {
        const newRole = e.target.value;
        handleInputChange(e);
        updateAccessTypesByRole(newRole);
    };

    const handleAccessTypeToggle = (type) => {
        if (editingIndex !== null && !partialAccess) {
            // In edit mode, allow changes only if partial access is enabled
            return;
        }

        setAccessTypes(prev => ({
            ...prev,
            [type]: !prev[type]
        }));
    };

    const handlePartialAccessChange = (e) => {
        const isChecked = e.target.checked;
        setPartialAccess(isChecked);

        if (!isChecked && editingIndex !== null) {
            // If partial access is disabled in edit mode, reset to role-based defaults
            updateAccessTypesByRole(formData.role);
        }
    };

    const handleModalSubmit = (e) => {
        e.preventDefault();

        // Prepare the data with access types
        const submitData = {
            ...formData,
            accessTypes,
            partialAccess,
            intervene,
            access: getAccessText()
        };

        handleSubmit(e, submitData);
    };

    const getAccessText = () => {
        const selectedTypes = Object.keys(accessTypes).filter(type => accessTypes[type]);
        if (selectedTypes.length === 0) return "No Access";
        return selectedTypes.map(type =>
            type.charAt(0).toUpperCase() + type.slice(1).replace(/([A-Z])/g, ' $1')
        ).join(", ");
    };

    const isTypeDisabled = editingIndex !== null && !partialAccess;

    // Get available types based on role
    const getAvailableTypes = () => {
        const types = [
            { key: 'chatAgent', label: 'Chat Agent' },
            { key: 'ticketing', label: 'Ticketing' },
            { key: 'leads', label: 'Leads' },
            { key: 'appointment', label: 'Appointment' }
        ];

        switch (formData.role) {
            case "Agent":
                return types.filter(type => type.key === 'chatAgent');
            case "Super Agent":
                return types.filter(type => type.key === 'chatAgent');
            case "Admin":
                return types;
            default:
                return [];
        }
    };

    const availableTypes = getAvailableTypes();

    return (
        <div
            className="modal fade show d-block"
            style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
            tabIndex="-1"
        >
            <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content" style={{ width: "600px" }}>
                    <div className="modal-header">
                        <h3 className="modal-title">
                            <Icon
                                className="modal-icon-adjustments"
                                icon="material-symbols:support-agent"
                            />
                            {editingIndex !== null ? "Edit Agent" : "Create New Agent"}
                        </h3>
                        <button
                            type="button"
                            className="btn-close"
                            onClick={handleCancel}
                        >
                            <Icon icon="mingcute:close-line" />
                        </button>
                    </div>
                    <div className="modal-body">
                        <form onSubmit={handleModalSubmit}>
                            {/* Name Field */}
                            <div className="mb-3">
                                <label className="form-label required">Name</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="name"
                                    value={formData.name}
                                    onChange={handleInputChange}
                                    placeholder="Enter name"
                                    required
                                />
                            </div>

                            {/* Email Field */}
                            <div className="mb-3">
                                <label className="form-label required">Email</label>
                                <input
                                    type="email"
                                    className="form-control"
                                    name="email"
                                    value={formData.email}
                                    onChange={handleInputChange}
                                    placeholder="Enter email"
                                    required
                                />
                            </div>

                            {/* Password Field */}
                            <div className="mb-3">
                                <label className="form-label required">
                                    Password
                                    {editingIndex !== null && (
                                        <span className="text-success ms-2">
                                            <Icon icon="mingcute:check-fill" />
                                        </span>
                                    )}
                                </label>
                                <input
                                    type="password"
                                    className="form-control"
                                    name="password"
                                    value={formData.password}
                                    onChange={handleInputChange}
                                    placeholder="Enter password"
                                    required
                                />
                            </div>

                            {/* Mobile Number Field */}
                            <div className="mb-3">
                                <label className="form-label required">Mobile Number</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="mobileNumber"
                                    value={formData.mobileNumber}
                                    onChange={(e) => {
                                        const value = e.target.value;

                                        // Allow only +, numbers
                                        if (/^[0-9+]*$/.test(value)) {
                                            handleInputChange(e);
                                        }
                                    }}
                                    placeholder="+91XXXXXXXXXX"
                                    required
                                />
                                {!/^\+91[0-9]{10}$/.test(formData.mobileNumber) &&
                                    formData.mobileNumber.length > 0 && (
                                        <small className="text-danger">
                                            Enter valid number: +91 followed by 10 digits
                                        </small>
                                    )}
                            </div>

                            {/* Role Field */}
                            <div className="mb-3">
                                <label className="form-label required">Role</label>
                                <select
                                    className="form-select"
                                    name="role"
                                    value={formData.role}
                                    onChange={handleRoleChange}
                                    required
                                >
                                    <option value="">Select Role</option>
                                    <option value="Agent">Agent</option>
                                    <option value="Super Agent">Super Agent</option>
                                    <option value="Admin">Admin</option>
                                </select>
                            </div>

                            {/* Type Section - Only show if role is selected */}
                            {formData.role && (
                                <div className="mb-3">
                                    <label className="form-label required">Type</label>
                                    <div className="access-types-container">
                                        {availableTypes.map((type) => (
                                            <div
                                                key={type.key}
                                                className={`access-type-item ${isTypeDisabled ? 'disabled' : ''}`}
                                            >
                                                <span>{type.label}</span>
                                                <div
                                                    className={`toggle-switch ${accessTypes[type.key] ? 'active' : ''}`}
                                                    onClick={() => !isTypeDisabled && handleAccessTypeToggle(type.key)}
                                                >
                                                    <div className="toggle-slider"></div>
                                                </div>
                                            </div>
                                        ))}

                                        {availableTypes.length === 0 && (
                                            <div className="text-muted text-center py-2">
                                                Select a role to see available types
                                            </div>
                                        )}
                                    </div>
                                </div>
                            )}

                            {/* Partial Access Checkbox - Only show in edit mode */}
                            {editingIndex !== null && (
                                <div className="mb-3">
                                    <div className="form-check d-flex align-items-center justify-content-start">
                                        <input
                                            className="form-check-input"
                                            type="checkbox"
                                            id="partialAccess"
                                            checked={partialAccess}
                                            onChange={handlePartialAccessChange}
                                        />
                                        <label className="form-check-label" htmlFor="partialAccess">
                                            Partial Access
                                        </label>
                                    </div>
                                </div>
                            )}

                            <div className="mb-3">
                                <div className="form-check d-flex align-items-center justify-content-start">
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        id="partialAccess"
                                        checked={partialAccess}
                                        onChange={handlePartialAccessChange}
                                        disabled={editingIndex === null}
                                    />
                                    <label className="form-check-label" htmlFor="partialAccess">
                                        Partial Access
                                    </label>
                                </div>
                            </div>

                            {/* Intervene Checkbox */}
                            <div className="mb-3">
                                <div className="form-check d-flex align-items-center justify-content-start">
                                    <input
                                        className="form-check-input"
                                        type="checkbox"
                                        id="intervene"
                                        checked={intervene}
                                        onChange={(e) => setIntervene(e.target.checked)}
                                    />
                                    <label className="form-check-label" htmlFor="intervene">
                                        Intervene
                                    </label>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div className="modal-footer">
                        <button
                            type="button"
                            className="btn-secondary"
                            onClick={handleCancel}
                        >
                            Cancel
                        </button>
                        <button
                            type="button"
                            className="btn-primary"
                            onClick={handleModalSubmit}
                            disabled={!formValid}
                        >
                            {editingIndex !== null ? "Update" : "Create"}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddEditAgentModal;