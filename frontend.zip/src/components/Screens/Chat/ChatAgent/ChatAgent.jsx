import React, { useState, useEffect } from "react";
import "datatables.net-dt/js/dataTables.dataTables.js";
import { Icon } from "@iconify/react/dist/iconify.js";
import MasterLayout from "../../../../masterLayout/MasterLayout";
import Breadcrumb from "../../../Breadcrumb";
import EmptyState from "../../EmptyTables/EmptyTables";
import { useSnackbar } from "notistack";
import AddEditAgentModal from "../Modules/AddEditAgentModal"; // Import the new component

const ChatAgent = () => {
  const [showModal, setShowModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [agents, setAgents] = useState([]);
  const [editingIndex, setEditingIndex] = useState(null);
  const [deleteIndex, setDeleteIndex] = useState(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    mobileNumber: "",
    role: "",
  });
  const [formValid, setFormValid] = useState(false);

  const { enqueueSnackbar } = useSnackbar();

  // Load Agents from Localstorage on component mount
  useEffect(() => {
    const loadAgents = () => {
      try {
        const savedAgents = localStorage.getItem("chatagents");
        if (savedAgents && savedAgents !== "[object JSON]") {
          const parsedAgents = JSON.parse(savedAgents);
          setAgents(parsedAgents);
        }
      } catch (error) {
        console.error("Error loading agents from localStorage:", error);
        localStorage.removeItem("chatagents");
        setAgents([]);
      }
    };

    loadAgents();
  }, []);

  // Save Agents to Localstorage whenever agents change
  useEffect(() => {
    localStorage.setItem("chatagents", JSON.stringify(agents));
  }, [agents]);

  // Validate form whenever formData changes
  useEffect(() => {
    validateForm();
  }, [formData]);

  const validateForm = () => {
    const { name, email, password, mobileNumber, role } = formData;
    const isValid =
      name.trim() !== "" &&
      email.trim() !== "" &&
      password.trim() !== "" &&
      mobileNumber.trim() !== "" &&
      role.trim() !== "";

    setFormValid(isValid);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e, submitData = null) => {
    e.preventDefault();

    const dataToUse = submitData || formData;

    if (!formValid) {
      enqueueSnackbar("Please fill all required fields!", {
        variant: "error",
        autoHideDuration: 3000,
      });
      return;
    }

    if (editingIndex !== null) {
      // Edit existing agent
      const updatedAgents = [...agents];
      updatedAgents[editingIndex] = { ...dataToUse, id: agents[editingIndex].id };
      setAgents(updatedAgents);
      setEditingIndex(null);
      enqueueSnackbar("Agent updated successfully!", {
        variant: "success",
        autoHideDuration: 3000,
      });
    } else {
      // Add new agent
      const newAgent = {
        ...dataToUse,
        id: Date.now(),
      };
      setAgents([...agents, newAgent]);
      enqueueSnackbar("Agent added successfully!", {
        variant: "success",
        autoHideDuration: 3000,
      });
    }

    setShowModal(false);
    resetForm();
  };

  const handleCancel = () => {
    setShowModal(false);
    setEditingIndex(null);
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      password: "",
      mobileNumber: "",
      role: "",
    });
    setFormValid(false);
  };

  const handleEdit = (index) => {
    setFormData(agents[index]);
    setEditingIndex(index);
    setShowModal(true);
  };

  const handleDeleteClick = (index) => {
    setDeleteIndex(index);
    setShowDeleteModal(true);
  };

  const handleDeleteConfirm = () => {
    if (deleteIndex !== null) {
      const agentName = agents[deleteIndex].name;
      const updatedAgents = agents.filter((_, i) => i !== deleteIndex);
      setAgents(updatedAgents);
      enqueueSnackbar(`Agent "${agentName}" deleted successfully!`, {
        variant: "error",
        autoHideDuration: 3000,
      });
    }
    setShowDeleteModal(false);
    setDeleteIndex(null);
  };

  const handleDeleteCancel = () => {
    setShowDeleteModal(false);
    setDeleteIndex(null);
  };

  const openAddModal = () => {
    setEditingIndex(null);
    resetForm();
    setShowModal(true);
  };

  return (
    <MasterLayout>
      <Breadcrumb title="Manage Agent" />

      {/* Add Chat Agent Button */}
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div></div>
        <button
          className="btn-primary d-flex align-items-center gap-2"
          onClick={openAddModal}
        >
          <Icon style={{ fontSize: "20px" }} icon="mingcute:add-line" />
          Add Chat Agent
        </button>
      </div>

      <div className="card basic-data-table">
        <div className="card-body">
          <div className="table-responsive">
            <table className="table bordered-table mb-0">
              <thead>
                <tr>
                  <th scope="col">S.No.</th>
                  <th scope="col">Name</th>
                  <th scope="col">Email Id</th>
                  <th scope="col">Phone Number</th>
                  <th scope="col">Role</th>
                  <th scope="col">Access</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
                {agents.length > 0 ? (
                  agents.map((agent, index) => (
                    <tr key={agent.id || index}>
                      <td>{index + 1}</td>
                      <td>{agent.name}</td>
                      <td>{agent.email}</td>
                      <td>{agent.mobileNumber}</td>
                      <td>{agent.role}</td>
                      <td>{agent.access || "Assigned Chat Access"}</td>
                      <td>
                        <div className="d-flex">
                          <button
                            onClick={() => handleEdit(index)}
                            className="w-32-px h-32-px me-8 bg-gradient-start text-primary rounded-circle d-inline-flex align-items-center justify-content-center border-0"
                          >
                            <Icon icon="lucide:edit" />
                          </button>
                          <button
                            onClick={() => handleDeleteClick(index)}
                            className="w-32-px h-32-px me-8 bg-gradient-start text-primary rounded-circle d-inline-flex align-items-center justify-content-center border-0"
                          >
                            <Icon icon="mingcute:delete-2-line" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="7">
                      <div className="d-flex flex-column align-items-center justify-content-center">
                        <EmptyState />
                        <p className="mt-3 text-muted">No Data</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Use the new modal component */}
      {showModal && (
        <AddEditAgentModal
          showModal={showModal}
          handleCancel={handleCancel}
          handleSubmit={handleSubmit}
          formData={formData}
          handleInputChange={handleInputChange}
          formValid={formValid}
          editingIndex={editingIndex}
        />
      )}

      {/* Delete Modal remains the same */}
      {showDeleteModal && (
        <div
          className="modal fade show d-block"
          style={{ backgroundColor: "rgba(0,0,0,0.5)" }}
          tabIndex="-1"
        >
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content" style={{ width: "500px" }}>
              <div className="modal-header">
                <h3 className="modal-title">Delete Confirmation</h3>
                <button
                  type="button"
                  className="btn-close"
                  onClick={handleDeleteCancel}
                >
                  <Icon icon="mingcute:close-line" />
                </button>
              </div>
              <div className="modal-body">
                <div className="">
                  <h6 className="mb-3 text-primary-2">
                    Are you sure you want to delete this agent?
                  </h6>
                </div>
              </div>
              <div className="modal-footer justify-content-end">
                <button
                  type="button"
                  className="btn-secondary"
                  onClick={handleDeleteCancel}
                >
                  Cancel
                </button>
                <button
                  type="button"
                  className="btn-primary"
                  onClick={handleDeleteConfirm}
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </MasterLayout>
  );
};

export default ChatAgent;