import React from "react";
import { Icon } from "@iconify/react";

const EditScheduleModal = ({ isOpen, onClose, campaignData, onSave }) => {
  if (!isOpen) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle form submission here
    onSave(campaignData);
  };

  return (
    <div className="modal fade show" style={{ display: "block", backgroundColor: "rgba(0,0,0,0.5)" }}>
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Edit Schedule</h5>
            <button
              type="button"
              className="btn-close"
              onClick={onClose}
            >
              <Icon icon="material-symbols:close-rounded" />
            </button>
          </div>
          <div className="modal-body">
            <form onSubmit={handleSubmit}>
              {/* Campaign ID */}
              <div className="mb-3">
                <label className="form-label fw-semibold">Campaign ID</label>
                <input style={{ cursor: "not-allowed" }}
                  type="text"
                  className="form-control"
                  value={campaignData?.campaignId || ""}
                  disabled
                />
              </div>

              {/* Phone Number */}
              <div className="mb-3">
                <label className="form-label fw-semibold">Phone Number</label>

                <input
                  style={{ cursor: "not-allowed" }}
                  type="text"
                  className="form-control"
                  value={campaignData?.phoneNumber || ""}
                  placeholder="+919876543210"
                  disabled
                  onChange={(e) => {
                    const value = e.target.value;

                    // Allow only + and numbers
                    if (!/^[0-9+]*$/.test(value)) return;

                    // You can update here if you later enable the field
                    // handlePhoneUpdate(value);
                  }}
                />

                {/* Validation message */}
                {campaignData?.phoneNumber &&
                  !/^\+91[0-9]{10}$/.test(campaignData.phoneNumber) && (
                    <small className="text-danger">
                      Enter valid Mobile Number (Format: +91 followed by 10 digits)
                    </small>
                  )}
              </div>


              {/* Timezone */}
              <div className="mb-3">
                <label className="form-label fw-semibold">* Timezone</label>
                <select style={{ cursor: "not-allowed" }} className="form-select" disabled value={campaignData?.timezone || ""}>
                  <option value="Asia/Kolkata">Asia/Kolkata (India)</option>
                  <option value="UTC">UTC</option>
                  <option value="America/New_York">America/New_York</option>
                  {/* Add more timezones as needed */}

                </select>
              </div>

              {/* Schedule Time */}
              <div className="mb-3">
                <label className="form-label fw-semibold">* Schedule Time</label>
                <input style={{ cursor: "not-allowed" }}
                  type="datetime-local"
                  className="form-control"
                  value={campaignData?.scheduleTime || ""}
                  onChange={(e) => {/* Handle change */ }}
                  disabled
                />
              </div>

              {/* Type */}
              <div className="mb-3">
                <label className="form-label fw-semibold">Type</label>
                <select className="form-select" style={{ cursor: "not-allowed" }} disabled value={campaignData?.type || ""}>
                  <option value="Marketing">Marketing</option>
                  <option value="Transactional">Transactional</option>
                  <option value="Service">Service</option>
                </select>
              </div>

              {/* Status */}
              <div className="mb-3">
                <label className="form-label fw-semibold">Status</label>
                <select style={{ cursor: "not-allowed" }} className="form-select" disabled value={campaignData?.status || ""}>
                  <option value="Sent">Sent</option>
                  <option value="Scheduled">Scheduled</option>
                  <option value="Draft">Draft</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>
            </form>
          </div>
          <div className="modal-footer">
            <button
              type="button"
              className="btn-secondary"
              onClick={onClose}
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditScheduleModal;