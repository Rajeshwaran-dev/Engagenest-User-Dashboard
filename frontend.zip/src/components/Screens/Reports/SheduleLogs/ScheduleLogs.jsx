import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ReactApexChart from "react-apexcharts";
import useReactApexChart from "../../../../hook/useReactApexChart";
import MasterLayout from "../../../../masterLayout/MasterLayout";
import Breadcrumb from "../../../Breadcrumb";
import DateRangePicker from "../../Calendar/DateRangePicker";
import EditScheduleModal from "../Modules/EditScheduleModal";
import { useSnackbar } from "notistack";

const SchduledLogs = () => {
  const { enqueueSnackbar } = useSnackbar();
  let { zoomAbleLineChartSeries, zoomAbleLineChartOptions } =
    useReactApexChart();

  const [selectedDateRange, setSelectedDateRange] = useState({
    startDate: null,
    endDate: null,
  });

  const [selectedCampaign, setSelectedCampaign] = useState(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [editingCampaign, setEditingCampaign] = useState(null);
  const [openMenu, setOpenMenu] = useState(null);

  const handleDateChange = ({ startDate, endDate }) => {
    setSelectedDateRange({ startDate, endDate });
    console.log("Selected Date Range:", { startDate, endDate });
  };

  useEffect(() => {
    function onDocClick(e) {
      if (!e.target.closest(".action-row")) {
        setOpenMenu(null);
      }
    }
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, []);

  // Sample campaign data
  const campaigns = [
    {
      id: 1,
      campaignName: "scheduled-ticket",
      campaignId: "CAMP-475",
      phoneNumber: "917845486703",
      timezone: "Asia/Kolkata",
      scheduleTime: "2025-09-20T12:11:00",
      type: "marketing",
      status: "sent",
      publishedTime: "01/11/2025 05:35 PM",
      submitted: 488,
      failedUsers: 174,
      sent: 314,
      delivered: 236,
      read: 219,
      replied: 0,
      status: "Complete",
      message: "Your scheduled message has been sent successfully. Reference ID: {{ref_id}}.",
      contacts: [
        { id: 1, mobile: "919360512179", failed: false, sent: true, delivered: true, read: true, replied: false, reason: "" },
        { id: 2, mobile: "919042498025", failed: false, sent: true, delivered: true, read: true, replied: false, reason: "" },
        { id: 3, mobile: "919655196943", failed: false, sent: true, delivered: true, read: false, replied: false, reason: "" },
        { id: 4, mobile: "919360512179", failed: true, sent: false, delivered: false, read: false, replied: false, reason: "Schedule time expired" },
        { id: 5, mobile: "919042498025", failed: true, sent: false, delivered: false, read: false, replied: false, reason: "Invalid schedule" },
      ]
    },
    {
      id: 2,
      campaignName: "scheduled-alert",
      campaignId: "CAMP-476",
      phoneNumber: "917845486704",
      timezone: "Asia/Kolkata",
      scheduleTime: "2025-09-21T12:45:00",
      type: "transactional",
      status: "scheduled",
      publishedTime: "01/11/2025 12:45 PM",
      submitted: 68,
      failedUsers: 3,
      sent: 65,
      delivered: 5,
      read: 5,
      replied: 0,
      status: "Complete",
      message: "Your scheduled service update is completed successfully.",
      contacts: [
        { id: 1, mobile: "919360512179", failed: false, sent: true, delivered: true, read: false, replied: false, reason: "" },
        { id: 2, mobile: "919042498025", failed: false, sent: true, delivered: true, read: false, replied: false, reason: "" },
        { id: 3, mobile: "919655196943", failed: true, sent: false, delivered: false, read: false, replied: false, reason: "Schedule conflict" },
        { id: 4, mobile: "919360512179", failed: true, sent: false, delivered: false, read: false, replied: false, reason: "Time slot unavailable" },
      ]
    }
  ];

  const handleRowClick = (campaign) => {
    setSelectedCampaign(campaign);
  };

  const handleBack = () => {
    setSelectedCampaign(null);
  };

  const handleEditClick = (campaign, e) => {
    e.stopPropagation();
    setEditingCampaign(campaign);
    setIsEditModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsEditModalOpen(false);
    setEditingCampaign(null);
  };

  const handleSaveSchedule = (updatedCampaign) => {
    console.log("Saving campaign:", updatedCampaign);
    // Here you would typically make an API call to update the campaign
    // For now, we'll just close the modal
    setIsEditModalOpen(false);
    setEditingCampaign(null);

    // Show success message or update local state if needed
    enqueueSnackbar("Schedule updated successfully!", { variant: "success" });
  };

  // If campaign is selected, show detail view
  if (selectedCampaign) {
    return (
      <MasterLayout>
        <Breadcrumb title="Scheduled Reports" />

        {/* Action Bar */}
        <div style={{ marginTop: "20px", marginBottom: "20px" }} className="d-flex align-items-center justify-content-between">
          <div className="d-flex gap-3">
            <button
              onClick={handleBack}
              className="btn-primary d-flex align-items-center gap-2"
              style={{ height: "40px" }}
            >
              <Icon icon="solar:arrow-left-outline" style={{ fontSize: "20px" }} />
              Back
            </button>
            <input
              type="text"
              placeholder="Search Contact"
              className="form-control d-md-none"
              style={{ width: "250px", height: "40px" }}
            />
          </div>
          <button className="btn-primary d-flex align-items-center gap-2" style={{ height: "40px" }}>
            <Icon icon="typcn:download" style={{ fontSize: "20px" }} />
            Download Report
          </button>
        </div>

        <div className="row">
          {/* Table Section */}
          <div className="col-xxl-8 col-xl-7">
            <div className="card basic-data-table">
              <div className="card-body">
                <div className="table-responsive">
                  <table className="table bordered-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col">S.No.</th>
                        <th scope="col">Mobile Number</th>
                        <th scope="col" className="text-center">Failed</th>
                        <th scope="col" className="text-center">Sent</th>
                        <th scope="col" className="text-center">Delivered</th>
                        <th scope="col" className="text-center">Read</th>
                        <th scope="col" className="text-center">Replied</th>
                        <th scope="col" className="text-center">Reason</th>
                        <th scope="col" className="text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedCampaign.contacts.map((contact, index) => (
                        <tr key={contact.id}>
                          <td>{index + 1}</td>
                          <td>
                            <h6 className="text-md mb-0 fw-medium flex-grow-1">
                              {contact.mobile}
                            </h6>
                          </td>
                          <td className="text-center">
                            {contact.failed && (
                              <Icon icon="icon-park-solid:check-one" className="text-success" style={{ fontSize: "20px" }} />
                            )}
                          </td>
                          <td className="text-center">
                            {contact.sent && (
                              <Icon icon="icon-park-solid:check-one" className="text-success" style={{ fontSize: "20px" }} />
                            )}
                          </td>
                          <td className="text-center">
                            {contact.delivered && (
                              <Icon icon="icon-park-solid:check-one" className="text-success" style={{ fontSize: "20px" }} />
                            )}
                          </td>
                          <td className="text-center">
                            {contact.read && (
                              <Icon icon="icon-park-solid:check-one" className="text-success" style={{ fontSize: "20px" }} />
                            )}
                          </td>
                          <td className="text-center">
                            {contact.replied && (
                              <Icon icon="icon-park-solid:check-one" className="text-success" style={{ fontSize: "20px" }} />
                            )}
                          </td>
                          <td className="text-center">
                            {contact.reason && (
                              <Icon icon="mdi:close-circle" className="text-danger" style={{ fontSize: "20px" }} />
                            )}
                          </td>
                          <td className="text-center">
                            <button
                              className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                            >
                              <Icon icon="carbon:view" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile Preview Section */}
          <div className="col-xxl-4 col-xl-5">
            <div className="card h-100">
              <div className="card-body d-flex align-items-center justify-content-center">
                {/* iPhone Frame - Same as before */}
                <div style={{ position: "relative", width: "280px", height: "570px" }}>
                  {/* Phone Border */}
                  <div style={{
                    position: "absolute",
                    inset: "0",
                    background: "#1a1a1a",
                    borderRadius: "45px",
                    boxShadow: "0 20px 60px rgba(0,0,0,0.3)",
                    padding: "12px"
                  }}>
                    {/* Notch */}
                    <div style={{
                      position: "absolute",
                      top: "0",
                      left: "50%",
                      transform: "translateX(-50%)",
                      width: "128px",
                      height: "24px",
                      background: "#1a1a1a",
                      borderRadius: "0 0 20px 20px",
                      zIndex: "10"
                    }}></div>

                    {/* Screen */}
                    <div style={{
                      position: "relative",
                      background: "#fff",
                      width: "100%",
                      height: "100%",
                      borderRadius: "35px",
                      overflow: "hidden"
                    }}>
                      {/* WhatsApp Header */}
                      <div style={{
                        background: "#075e54",
                        height: "80px",
                        display: "flex",
                        alignItems: "flex-end",
                        padding: "0 16px 8px"
                      }}>
                        <div style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "end",
                          width: "100%"
                        }}>
                          <div style={{ color: "#fff", fontSize: "20px" }}>⋮</div>
                        </div>
                      </div>

                      {/* Message Area */}
                      <div style={{
                        background: "#e5ddd5",
                        height: "calc(100% - 132px)",
                        padding: "16px",
                        overflowY: "auto"
                      }}>
                        {/* Message Bubble */}
                        <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: "16px" }}>
                          <div style={{
                            background: "#fff",
                            borderRadius: "8px",
                            padding: "12px",
                            boxShadow: "0 1px 2px rgba(0,0,0,0.1)",
                            maxWidth: "220px",
                            position: "relative"
                          }}>
                            <div style={{
                              position: "absolute",
                              right: "-8px",
                              top: "0",
                              width: "0",
                              height: "0",
                              borderLeft: "8px solid #fff",
                              borderTop: "8px solid transparent"
                            }}></div>
                            <p style={{
                              fontSize: "13px",
                              color: "#303030",
                              lineHeight: "1.5",
                              margin: "0"
                            }}>
                              {selectedCampaign.message}
                            </p>
                            <div style={{
                              display: "flex",
                              alignItems: "center",
                              justifyContent: "flex-end",
                              gap: "4px",
                              marginTop: "4px"
                            }}>
                              <span style={{ fontSize: "11px", color: "#667781" }}>12:45 PM</span>
                              <Icon icon="bi:check-all" style={{ fontSize: "14px", color: "#53bdeb" }} />
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Input Bar */}
                      <div style={{
                        position: "absolute",
                        bottom: "0",
                        left: "0",
                        right: "0",
                        background: "#f0f0f0",
                        padding: "8px",
                        display: "flex",
                        alignItems: "center",
                        gap: "8px",
                        borderTop: "1px solid #ddd"
                      }}>
                        <span style={{ fontSize: "20px" }}>😊</span>
                        <input
                          type="text"
                          placeholder="Message"
                          style={{
                            flex: "1",
                            background: "#fff",
                            border: "none",
                            borderRadius: "20px",
                            padding: "8px 16px",
                            fontSize: "13px",
                            outline: "none"
                          }}
                          disabled
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </MasterLayout>
    );
  }

  return (
    <MasterLayout>
      <Breadcrumb title="Scheduled Reports" />

      {/* Edit Schedule Modal */}
      <EditScheduleModal
        isOpen={isEditModalOpen}
        onClose={handleCloseModal}
        campaignData={editingCampaign}
        onSave={handleSaveSchedule}
      />

      <div className="col-xxl-12">
        <div className="card h-100">
          <div className="card-header border-bottom bg-base ps-0 py-0 pe-24 d-flex align-items-center justify-content-between">
            <ul
              className="nav bordered-tab nav-pills mb-0"
              id="pills-tab"
              role="tablist"
            >
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link active new-flex"
                  id="pills-to-do-list-tab"
                  data-bs-toggle="pill"
                  data-bs-target="#pills-to-do-list"
                  type="button"
                  role="tab"
                  aria-controls="pills-to-do-list"
                  aria-selected="true"
                >
                  <Icon
                    className="icon-adjustments"
                    icon="oui:nav-reports"
                  />
                  Scheduled Reports
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link new-flex"
                  id="pills-recent-leads-tab"
                  data-bs-toggle="pill"
                  data-bs-target="#pills-recent-leads"
                  type="button"
                  role="tab"
                  aria-controls="pills-recent-leads"
                  aria-selected="false"
                  tabIndex={-1}
                >
                  <Icon
                    className="icon-adjustments"
                    icon="iconoir:reports"
                  />
                  Scheduled Logs
                </button>
              </li>
            </ul>
          </div>

          <div className="card-body p-24">
            <div className="tab-content" id="pills-recent-leads-tab">
              <div
                className="tab-pane fade"
                id="pills-recent-leads"
                role="tabpanel"
                aria-labelledby="pills-recent-leads-tab"
                tabIndex={0}
              >
                <div className="table-responsive scroll-sm">
                  <table className="table bordered-table mb-0">
                    <thead>
                      <tr>
                        <th scope="col">S.No</th>
                        <th scope="col">Campaign Name</th>
                        <th scope="col">Scheduled Time</th>
                        <th scope="col">Created At</th>
                        <th scope="col">Status</th>
                        <th scope="col">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <span>01</span>
                        </td>
                        <td>
                          <h6 className="text-md mb-0 fw-medium flex-grow-1">
                            CAMP-475
                          </h6>
                        </td>
                        <td>
                          <h6 className="text-md mb-0 fw-medium flex-grow-1">
                            20/09/2025 12:11 PM
                          </h6>
                        </td>
                        <td>
                          <h6 className="text-md mb-0 fw-medium flex-grow-1">
                            20/09/2025 12:09 PM
                          </h6>
                        </td>
                        <td>
                          <span className="badge text-sm fw-semibold px-20 py-9 radius-4 text-white bg-success">Sent</span>
                        </td>
                        <td>
                          <button
                            className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                            onClick={(e) => handleEditClick(campaigns[0], e)}
                          >
                            <Icon icon="bx:edit" />
                          </button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          <div className="card-body p-24">
            <div className="tab-content" id="pills-tabContent">
              <div
                className="tab-pane fade show active"
                id="pills-to-do-list"
                role="tabpanel"
                aria-labelledby="pills-to-do-list-tab"
                tabIndex={0}
              >
                <div className="col-xxl-12">
                  <div className="card h-100 radius-8 border-0">
                    <div className="card-body p-24">
                      <div className="d-flex align-items-start flex-wrap gap-2">
                        <div>
                          <h6 className="mb-2 text-lg">
                            Delivery Chart for last 7 Days Report
                          </h6>
                        </div>
                      </div>
                      <div id="barChart">
                        <ReactApexChart
                          id="zoomAbleLineChart"
                          options={zoomAbleLineChartOptions}
                          series={zoomAbleLineChartSeries}
                          type="area"
                          height={264}
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="card basic-data-table">
                  <div className="card-body">
                    <div style={{ marginBottom: "20px" }} className="d-flex align-items-center flex-wrap gap-2 justify-content-end">
                      <div className="d-flex gap-3 align-items-center">
                        <div className="d-md-none">
                          <DateRangePicker 
                            onDateChange={handleDateChange}
                            placeholder="Select date range"
                          />
                        </div>

                        <button style={{ height: "40px", marginTop: "0px" }} className="btn-primary d-flex align-items-center gap-2">
                          <Icon
                            style={{ fontSize: "20px" }}
                            icon="typcn:download"
                          />
                          Download Report
                        </button>
                        <div className="tooltip-container">
                          <button className="d-flex align-items-center justify-content-center">
                            <Icon
                              icon="fa-regular:question-circle"
                              style={{ fontSize: "24px", color: "var(--text-secondary)" }}
                            />
                          </button>

                          <div className="custom-tooltip">
                            Click "Download Report" for the last 7 days report or select a date for a
                            specific report on the filter.
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="table-responsive position-relative">
                      <table className="table bordered-table mb-0">
                        <thead>
                          <tr>
                            <th scope="col">
                              <div className="form-check style-check d-flex align-items-center">
                                <label className="form-check-label">S.No.</label>
                              </div>
                            </th>
                            <th scope="col">Campaign Name</th>
                            <th scope="col">Published Time</th>
                            <th scope="col">Submitted</th>
                            <th scope="col">Failed Users</th>
                            <th scope="col">Sent</th>
                            <th scope="col">Delivered</th>
                            <th scope="col">Read</th>
                            <th scope="col">Replied</th>
                            <th scope="col">Status</th>
                            <th scope="col" className="fixed-action-column">Trigger</th>
                          </tr>
                        </thead>
                        <tbody>
                          {campaigns.map((campaign, index) => (
                            <tr
                              key={campaign.id}
                              onClick={() => handleRowClick(campaign)}
                              style={{ cursor: "pointer" }}
                            >
                              <td>
                                <div className="form-check style-check d-flex align-items-center">
                                  <label className="form-check-label">{index + 1}</label>
                                </div>
                              </td>
                              <td className="fw-bold text-primary-2">
                                {campaign.campaignName}
                              </td>
                              <td>{campaign.publishedTime}</td>
                              <td>{campaign.submitted}</td>
                              <td>{campaign.failedUsers}</td>
                              <td>{campaign.sent}</td>
                              <td>{campaign.delivered}</td>
                              <td>{campaign.read}</td>
                              <td>{campaign.replied}</td>
                              <td>
                                <span className="badge text-sm fw-semibold px-20 py-9 radius-4 text-white bg-success">
                                  {campaign.status}
                                </span>
                              </td>
                              <td className="fixed-action-column">
                                <div className="d-flex">
                                  <button
                                    to="#"
                                    className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <Icon icon="heroicons-outline:document-duplicate" />
                                  </button>
                                  <button
                                    to="#"
                                    className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <Icon icon="ant-design:read-outlined" />
                                  </button>
                                  <button
                                    to="#"
                                    className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <Icon icon="hugeicons:package-delivered" />
                                  </button>
                                  <button
                                    to="#"
                                    className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <Icon icon="basil:reply-outline" />
                                  </button>
                                  <button
                                    to="#"
                                    className="w-32-px h-32-px me-8 bg-gradient-start text-bg-primary rounded-circle d-inline-flex align-items-center justify-content-center"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <Icon icon="icon-park-outline:file-failed" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </MasterLayout>
  );
};

export default SchduledLogs;