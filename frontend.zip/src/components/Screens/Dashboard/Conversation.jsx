import { Icon } from "@iconify/react/dist/iconify.js";
import React, { useState, useEffect } from "react";
import {
  useGetTotalConvoQuery,
  useGetUserBalanceQuery
} from "../../../store/ApiFilesV2/UserApis";
import AddFundModal from "./Modules/AddFundModal";
import UpgradeModal from "./Modules/UpgradeModal";

const Conversation = () => {
  const [selectedFilter, setSelectedFilter] = useState("1"); // Default: Last 7 days
  const [conversationStats, setConversationStats] = useState({
    marketing: 0,
    authentication: 0,
    utility: 0,
    service: 0,
    business: 0,
    user: 0,
    total: 0
  });

  // Fetch conversation data
  const { data: conversationData } = useGetTotalConvoQuery(
    { filter: selectedFilter },
    { skip: !selectedFilter }
  );

  // Fetch user balance
  const { data: balanceData, isLoading: balanceLoading } = useGetUserBalanceQuery();

  const [isAddFundModalOpen, setIsAddFundModalOpen] = useState(false);
  const [isUpgradeModalOpen, setIsUpgradeModalOpen] = useState(false);

  // Safely update conversation stats - FIX FOR THE ERROR
  useEffect(() => {
    if (!conversationData) {
      return;
    }

    // Ensure we're working with plain objects
    const data = conversationData.data || conversationData;

    setConversationStats({
      marketing: data.marketing || 0,
      authentication: data.authentication || 0,
      utility: data.utility || 0,
      service: data.service || 0,
      business: data.business || 0,
      user: data.user || 0,
      total: data.total || 0
    });
  }, [conversationData]);

  // Handle filter change
  const handleFilterChange = (filter) => {
    setSelectedFilter(filter);
  };

  // Safely get balance - FIX FOR THE ERROR
  const getBalance = () => {
    if (!balanceData || balanceLoading) {
      return { balance: 0, lockedBalance: 0 };
    }

    // Ensure we're working with plain objects
    const data = balanceData.data || balanceData;

    return {
      balance: data.balance || 0,
      lockedBalance: data.lockedBalance || 0
    };
  };

  const balanceInfo = getBalance();

  return (
    <>
      <div className="row gy-4">
        {/* Filter Buttons */}
        <div className="col-12">
          <div className="d-flex gap-2 mb-3">
            <button
              className={`btn btn-sm ${selectedFilter === "0" ? "btn-primary" : "btn-outline-primary"}`}
              onClick={() => handleFilterChange("0")}
            >
              Today
            </button>
            <button
              className={`btn btn-sm ${selectedFilter === "1" ? "btn-primary" : "btn-outline-primary"}`}
              onClick={() => handleFilterChange("1")}
            >
              Last 7 Days
            </button>
            <button
              className={`btn btn-sm ${selectedFilter === "2" ? "btn-primary" : "btn-outline-primary"}`}
              onClick={() => handleFilterChange("2")}
            >
              Last 28 Days
            </button>
            <button
              className={`btn btn-sm ${selectedFilter === "3" ? "btn-primary" : "btn-outline-primary"}`}
              onClick={() => handleFilterChange("3")}
            >

              All Time
            </button>
          </div>
        </div>

        {/* UnitCountTwo Section - 8 columns */}
        <div className="col-xxl-8 m-0 p-0">
          <div className="row gy-4">
            {/* Marketing */}
            <div className="col-xxl-4 col-sm-12 col-md-6 mt-8">
              <div className="card px-24 py-16 shadow-none radius-8 border h-100 bg-gradient-start">
                <div className="card-body p-0">
                  <div className="d-flex flex-wrap align-items-center justify-content-between gap-1 mb-8">
                    <div className="d-flex align-items-center">
                      <div className="w-64-px h-64-px radius-16 bg-base-50 d-flex justify-content-center align-items-center me-20">
                        <span className="mb-0 w-40-px h-40-px bg-primary flex-shrink-0 text-white d-flex justify-content-center align-items-center radius-8 h6 mb-0">
                          <Icon
                            icon="nimbus:marketing"
                            className="icon"
                          />
                        </span>
                      </div>
                      <div>
                        <span className="mb-2 fw-medium text-secondary-light text-md">
                          Marketing
                        </span>
                        <h6 className="fw-semibold my-1">
                          {conversationStats.marketing}
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Authentication */}
            <div className="col-xxl-4 col-sm-12 col-md-6 mt-8">
              <div className="card px-24 py-16 shadow-none radius-8 border h-100 bg-gradient-start">
                <div className="card-body p-0">
                  <div className="d-flex flex-wrap align-items-center justify-content-between gap-1 mb-8">
                    <div className="d-flex align-items-center">
                      <div className="w-64-px h-64-px radius-16 bg-base-50 d-flex justify-content-center align-items-center me-20">
                        <span className="mb-0 w-40-px h-40-px bg-primary flex-shrink-0 text-white d-flex justify-content-center align-items-center radius-8 h6 mb-0">
                          <Icon
                            icon="carbon:two-factor-authentication"
                            className="text-white text-2xl mb-0"
                          />
                        </span>
                      </div>
                      <div>
                        <span className="mb-2 fw-medium text-secondary-light text-md">
                          Authentication
                        </span>
                        <h6 className="fw-semibold my-1">
                          {conversationStats.authentication}
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Utility */}
            <div className="col-xxl-4 col-sm-12 col-md-6 mt-8">
              <div className="card px-24 py-16 shadow-none radius-8 border h-100 bg-gradient-start">
                <div className="card-body p-0">
                  <div className="d-flex flex-wrap align-items-center justify-content-between gap-1 mb-8">
                    <div className="d-flex align-items-center">
                      <div className="w-64-px h-64-px radius-16 bg-base-50 d-flex justify-content-center align-items-center me-20">
                        <span className="mb-0 w-40-px h-40-px bg-primary flex-shrink-0 text-white d-flex justify-content-center align-items-center radius-8 h6 mb-0">
                          <Icon
                            icon="material-symbols:business-center-outline-sharp"
                            className="text-white text-2xl mb-0"
                          />
                        </span>
                      </div>
                      <div>
                        <span className="mb-2 fw-medium text-secondary-light text-md">
                          Utility
                        </span>
                        <h6 className="fw-semibold my-1">
                          {conversationStats.utility}
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* User initiated */}
            <div className="col-xxl-4 col-sm-12 col-md-6 mt-8">
              <div className="card px-24 py-16 shadow-none radius-8 border h-100 bg-gradient-start">
                <div className="card-body p-0">
                  <div className="d-flex flex-wrap align-items-center justify-content-between gap-1 mb-8">
                    <div className="d-flex align-items-center">
                      <div className="w-64-px h-64-px radius-16 bg-base-50 d-flex justify-content-center align-items-center me-20">
                        <span className="mb-0 w-40-px h-40-px bg-primary flex-shrink-0 text-white d-flex justify-content-center align-items-center radius-8 h6 mb-0">
                          <Icon
                            icon="solar:user-outline"
                            className="icon"
                          />
                        </span>
                      </div>
                      <div>
                        <span className="mb-2 fw-medium text-secondary-light text-md">
                          User initiated
                        </span>
                        <h6 className="fw-semibold my-1">
                          {conversationStats.user}
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Business initiated */}
            <div className="col-xxl-4 col-sm-12 col-md-6 mt-8">
              <div className="card px-24 py-16 shadow-none radius-8 border h-100 bg-gradient-start">
                <div className="card-body p-0">
                  <div className="d-flex flex-wrap align-items-center justify-content-between gap-1 mb-8">
                    <div className="d-flex align-items-center">
                      <div className="w-64-px h-64-px radius-16 bg-base-50 d-flex justify-content-center align-items-center me-20">
                        <span className="mb-0 w-40-px h-40-px bg-primary flex-shrink-0 text-white d-flex justify-content-center align-items-center radius-8 h6 mb-0">
                          <Icon
                            icon="icon-park-outline:user-business"
                            className="icon"
                          />
                        </span>
                      </div>
                      <div>
                        <span className="mb-2 fw-medium text-secondary-light text-md">
                          Business initiated
                        </span>
                        <h6 className="fw-semibold my-1">
                          {conversationStats.business}
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Total */}
            <div className="col-xxl-4 col-sm-12 col-md-6 mt-8">
              <div className="card px-24 py-16 shadow-none radius-8 border h-100 bg-gradient-start">
                <div className="card-body p-0">
                  <div className="d-flex flex-wrap align-items-center justify-content-between gap-1 mb-8">
                    <div className="d-flex align-items-center">
                      <div className="w-64-px h-64-px radius-16 bg-base-50 d-flex justify-content-center align-items-center me-20">
                        <span className="mb-0 w-40-px h-40-px bg-primary flex-shrink-0 text-white d-flex justify-content-center align-items-center radius-8 h6 mb-0">
                          <Icon
                            icon="icon-park-outline:data-all"
                            className="text-white text-2xl mb-0"
                          />
                        </span>
                      </div>
                      <div>
                        <span className="mb-2 fw-medium text-secondary-light text-md">
                          Total
                        </span>
                        <h6 className="fw-semibold my-1">
                          {conversationStats.total}
                        </h6>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RevenueGrowthOne Section - 4 columns */}
        <div className="col-xxl-2 col-md-6 col-sm-6 mt-8">
          <div className="radius-8 h-100 p-16 bg-gradient-start d-flex flex-column text-center justify-content-between">
            <h6 className="text-xl">Upgrade Your Plan</h6>
            <div className="">
              <p className="mb-3">Upgrade to access premium features</p>
              <button
                onClick={() => setIsUpgradeModalOpen(true)}
                className="btn-primary"
                disabled={balanceLoading}
              >
                Upgrade Now
              </button>
            </div>
          </div>
        </div>

        <div className="col-xxl-2 col-md-6 col-sm-6 mt-8">
          <div className="radius-8 h-100 p-16 bg-gradient-start d-flex flex-column">
            {/* Icon and Balance Info - Centered */}
            <div className="d-flex flex-column align-items-center justify-content-center text-center flex-grow-1">
              <div className="d-flex flex-column align-items-center">
                <span className="w-44-px h-44-px radius-8 d-flex justify-content-center align-items-center text-xl mb-3 border border-primary text-primary">
                  <i className="ri-money-rupee-circle-fill"></i>
                </span>
                <span className="text-neutral-700 d-block">
                  Available Balance
                </span>
                <h6 className="mb-3 mt-2">
                  ₹{parseFloat(balanceInfo.balance).toFixed(2)}
                  {balanceInfo.lockedBalance > 0 && (
                    <small className="text-warning d-block mt-1">
                      (Locked: ₹{parseFloat(balanceInfo.lockedBalance).toFixed(2)})
                    </small>
                  )}
                </h6>
              </div>
            </div>

            {/* Button - Fixed at bottom */}
            <div className="d-flex justify-content-center">
              <button
                onClick={() => setIsAddFundModalOpen(true)}
                className="btn-primary"
                style={{ minWidth: "120px" }}
              >
                Add Balance
              </button>
            </div>
          </div>
        </div>

        {/* Add Fund Modal */}
        <AddFundModal
          isOpen={isAddFundModalOpen}
          onClose={() => setIsAddFundModalOpen(false)}
        />

        {/* Upgrade Modal */}
        <UpgradeModal
          isOpen={isUpgradeModalOpen}
          onClose={() => setIsUpgradeModalOpen(false)}
        />
      </div>
    </>
  );
};

export default Conversation;