const useReactApexChart = () => {
  const zoomAbleLineChartOptions = {
    chart: {
      type: "area",
      height: 266,
      toolbar: { show: false },
    },
    stroke: {
      curve: "straight",
      width: 3,
      colors: ["#16ad1dff", "#cc0a0aff", "#2e09d4ff"],
    },
    dataLabels: { enabled: false },
    markers: {
      size: 4,
      strokeWidth: 2,
      hover: { size: 8 }
    },
    fill: {
      type: "gradient",
      gradient: {
        opacityFrom: 0.35,
        opacityTo: 0.1,
      },
    },
    xaxis: {
      categories: [],
      labels: {
        style: { fontSize: "13px" }
      }
    },
    yaxis: {
      labels: {
        formatter: (val) => val,
        style: { fontSize: "13px" }
      }
    },
    tooltip: {
      shared: true,
      intersect: false,
      y: { formatter: (val) => `${val} messages` }
    },
    legend: {
      show: true,
      position: "bottom",
      horizontalAlign: "center",
    },
  };

  return {
    zoomAbleLineChartOptions
  };
};

export default useReactApexChart;